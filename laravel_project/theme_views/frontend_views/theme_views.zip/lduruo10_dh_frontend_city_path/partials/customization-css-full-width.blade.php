<!-- Start page level nav style -->
<style>
    @media only screen and (min-width: 1400px) and (max-width: 1920px) {
        .header {
            padding: 0px 0px;
        }
    }
    .header {

        background-color: #ffffff;
    }
    .customization-header-font-color {
        color: #323232;
    }
    .customization-header-font-color:hover {
        color: #323232;
    }
    .header__menu ul li a {
        color: #323232;
    }
</style>
<!-- End page level nav style -->
