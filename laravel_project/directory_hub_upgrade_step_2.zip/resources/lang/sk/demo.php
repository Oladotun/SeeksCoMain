<?php 
return array (
  'purchase-button' => 'Nákup',
  'purchase-desc' => 'Tento produkt nepredávame mimo servera CodeCanyon. Nákup podpory od tohto pôvodného autora a doživotné aktualizácie.',
);