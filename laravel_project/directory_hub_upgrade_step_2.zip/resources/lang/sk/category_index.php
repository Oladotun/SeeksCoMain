<?php 
return array (
  'category-name-a-z' => 'Názov AZ',
  'category-name-z-a' => 'Názov ZA',
  'custom-field-name-a-z' => 'Názov AZ',
  'custom-field-name-z-a' => 'Názov ZA',
  'test-smtp' => 
  array (
    'email-subject' => 'Overte si tento test odosielania e -mailov prostredníctvom SMTP',
    'email-body' => 'Toto je testovací e -mail na overenie funkčnosti SMTP. Nasleduje náhodne generovaný text odseku.',
    'success-notify' => 'Testovací e -mail bol úspešne odoslaný. Overte prosím svoju e -mailovú schránku alebo spam. Pre vašu informáciu, testovací e -mail bol odoslaný na adresu:',
    'error-notify' => 'Pri odosielaní testovacieho e -mailu sa vyskytla chyba:',
    'enable-smtp-notify' => 'Ak chcete pokračovať v teste, povoľte protokol SMTP.',
    'send-a-test-email-link' => 'Pošlite testovací e -mail',
    'receiver-email' => 'Email príjemcu',
    'modal' => 
    array (
      'modal-title' => 'Otestujte nastavenie SMTP',
      'modal-description' => 'Na nižšie zadanú e -mailovú adresu bude odoslaný testovací e -mail s zadaným nastavením SMTP.',
      'modal-send' => 'Poslať teraz',
    ),
  ),
);