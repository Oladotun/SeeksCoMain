<?php 
return array (
  'seo' => 
  array (
    'edit-razorpay' => 'Dashboard - Edit Razorpay - :site_name',
  ),
  'alert' => 
  array (
    'value-required' => 'požadovaný',
    'update-razorpay-success' => 'Nastavenie Razorpay bolo úspešne aktualizované.',
  ),
  'edit-razorpay-setting' => 'Upravte platobnú bránu Razorpay',
  'edit-razorpay-setting-desc' => 'Táto stránka umožňuje povoliť alebo zakázať platobnú bránu Razorpay a upraviť nastavenia Razorpay.',
  'razorpay-enabled' => 'Razorpay povolené',
  'razorpay-disabled' => 'Razorpay zakázaný',
  'enable-razorpay' => 'Povoliť platobnú bránu Razorpay',
);