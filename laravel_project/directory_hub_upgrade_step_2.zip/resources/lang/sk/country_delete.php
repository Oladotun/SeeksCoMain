<?php 
return array (
  'alert' => 
  array (
    'country-delete-error-setting' => 'Táto krajina je predvolenou krajinou pre webové stránky. Pred odstránením prejdite na Dashboard správcu&gt; Nastavenie&gt; Všeobecné&gt; karta Informácie a zmeňte predvolenú krajinu.',
    'at-least-one-country' => 'Web musí mať aspoň jeden rekord krajiny.',
  ),
  'delete-country-warning' => 'Odstránením záznamu o krajine sa odstránia aj všetky pridružené záznamy, údaje o štátoch a mestách.',
  'delete-state-warning' => 'Odstránením záznamu stavu odstránite aj všetky pridružené záznamy a údaje miest.',
  'delete-city-warning' => 'Odstránením záznamu stavu sa odstránia aj všetky údaje pridruženého záznamu.',
);