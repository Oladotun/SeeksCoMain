<?php 
return array (
  'alert' => 
  array (
    'instamojo-failed' => 'Platba prostredníctvom služby Instamojo zlyhala.',
    'instamojo-success' => 'Instamojo Platba úspešná.',
    'instamojo-wrong' => 'S Instamojom sa niečo pokazilo',
  ),
);