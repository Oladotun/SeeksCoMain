<?php 
return array (
  'sitemap' => 
  array (
    'state' => 'Štát',
    'city' => 'Mesto',
  ),
  'alert' => 
  array (
    'url-starts-with' => 'Adresa URL musí začínať reťazcom http: // alebo https: //',
  ),
  'item-feature-image-url-help' => 'Zadajte webovú adresu obrázka, ktorá začína reťazcom http: // alebo https: //',
  'item-gallery-images-url-help' => 'Zadajte adresy URL obrázkov, ktoré začínajú reťazcom http: // alebo https: // a jedným riadkom na každú adresu URL',
  'column-item-feature-image' => 'zoznam profilov URL obrázku',
  'column-item-gallery-images' => 'zoznam adries obrázkov galérie',
  'csv-file-upload-listing-instruction-columns' => 'Stĺpce pre uvedenie: titul, slimák (voliteľné), adresa (voliteľné), mesto, štát, krajina, zemepisná šírka (voliteľné), zemepisná dĺžka (voliteľné), poštové smerovacie číslo, popis, telefón (voliteľné), webová stránka (voliteľné), facebook (voliteľné) ), twitter (možnosť), linkedin (možnosť), youtube id (možnosť), URL odporúčaného obrázka (možnosť), adresy URL obrázkov galérie (možnosť).',
  'csv-file-upload-listing-instruction-image-urls' => 'Adresy URL musia začínať reťazcom http: // alebo https: // v stĺpcoch adries URL odporúčaných obrázkov a adries URL obrázkov z galérie.',
  'csv-file-upload-listing-instruction-gallery-images-urls' => 'V stĺpci Adresy URL obrázkov v galérii oddeľte každú adresu URL obrázka medzerami.',
);