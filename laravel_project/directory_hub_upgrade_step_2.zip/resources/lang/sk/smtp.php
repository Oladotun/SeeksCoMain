<?php 
return array (
  'from-email' => 'Z e-mailu',
  'from-name' => 'Podľa mena',
  'smtp' => 'SMTP',
  'smtp-enabled' => 'Povoliť SMTP',
  'smtp-encryption' => 'Šifrovanie SMTP',
  'smtp-encryption-null' => 'NULOVÝ',
  'smtp-encryption-ssl' => 'SSL',
  'smtp-encryption-tls' => 'TLS',
  'smtp-host' => 'Hostiteľ SMTP',
  'smtp-password' => 'Heslo SMTP',
  'smtp-port' => 'Port SMTP',
  'smtp-username' => 'Používateľské meno SMTP',
);