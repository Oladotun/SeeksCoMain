<?php 
return array (
  'oauth-redirect-uri' => 'Identifikátor URI presmerovania OAuth',
);