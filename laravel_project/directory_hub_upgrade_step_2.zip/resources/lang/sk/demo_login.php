<?php 
return array (
  'demo-login-credentials' => 'Na prihlásenie použite náš demo účet',
  'admin-account' => 'Admin',
  'user-account' => 'Používateľ',
  'copy-to-login' => 'Kópia',
);