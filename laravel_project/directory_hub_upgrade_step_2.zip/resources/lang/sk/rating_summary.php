<?php 
return array (
  '1-stars' => '1 hviezdičky',
  '2-stars' => '2 hviezdičky',
  '3-stars' => '3 hviezdičky',
  '4-stars' => '4 hviezdičky',
  '5-stars' => '5 hviezdičiek',
  'based-on-review' => 'Na základe :item_rating_count kontroly',
  'based-on-reviews' => 'Na základe :item_rating_count recenzií',
  'sort-by' => 'Triediť podľa',
  'sort-by-newest' => 'Najnovšie prvé',
  'sort-by-oldest' => 'Najstaršie prvé',
  'sort-by-highest' => 'Najvyššie hodnotené',
  'sort-by-lowest' => 'Najnižšie hodnotené',
  'contact' => 'Kontakt',
  'managed-by' => 'Manažér',
);