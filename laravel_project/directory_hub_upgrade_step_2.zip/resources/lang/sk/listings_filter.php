<?php 
return array (
  'filters' => 'Filtre',
  'categories' => 'Kategórie',
  'sort-by' => 'Triediť podľa',
  'update-result' => 'Aktualizácia',
  'sort-by-newest' => 'Najnovšie prvé',
  'sort-by-oldest' => 'Najstaršie prvé',
  'sort-by-highest' => 'Najvyššie hodnotené',
  'sort-by-lowest' => 'Najnižšie hodnotené',
  'show-more' => 'Zobraziť viac',
  'show-less' => 'Zobraziť menej',
);