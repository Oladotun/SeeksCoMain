<?php 
return array (
  'category-description' => 'Popis kategórie',
  'records' => 'záznamy spolu',
);