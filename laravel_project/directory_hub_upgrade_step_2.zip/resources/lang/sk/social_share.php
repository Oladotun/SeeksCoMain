<?php 
return array (
  'blogger' => 'Blogger',
  'buffer' => 'Nárazník',
  'evernote' => 'Evernote',
  'facebook' => 'Facebook',
  'line' => 'Riadok',
  'linkedin' => 'LinkedIn',
  'pinterest' => 'Pinterest',
  'reddit' => 'Reddit',
  'skype' => 'Skype',
  'telegram' => 'Telegram',
  'twitter' => 'Twitter',
  'viber' => 'Viber',
  'wechat' => 'Wechat',
  'weibo' => 'Weibo',
  'whatsapp' => 'Whatsapp',
  'wordpress' => 'Wordpress',
);