<?php 
return array (
  'payment' => 'Platba',
  'paypal' => 'PayPal',
  'razorpay' => 'Razorpay',
  'enable-paypal' => 'Povoliť PayPal',
  'enable-razorpay' => 'Povoliť Razoray',
  'paypal-ipn' => 'PayPal IPN',
  'pay-paypal' => 'Plaťte cez PayPal',
  'pay-razorpay' => 'Plaťte pomocou Razorpay',
  'paypal-disable' => 'Platobná brána PayPal je deaktivovaná.',
);