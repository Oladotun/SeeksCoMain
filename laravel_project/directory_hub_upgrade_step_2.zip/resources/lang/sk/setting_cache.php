<?php 
return array (
  'seo' => 
  array (
    'edit-setting-cache' => 'Dashboard - Edit Cache - :site_name',
  ),
  'alert' => 
  array (
    'updated-success' => 'Vyrovnávacia pamäť webových stránok bola úspešne vygenerovaná.',
    'deleted-success' => 'Vyrovnávacia pamäť webových stránok bola úspešne vymazaná.',
  ),
  'manage-website-cache' => 'Spravovať medzipamäť webových stránok',
  'manage-website-cache-desc' => 'Táto stránka umožňuje generovať alebo vyčistiť medzipamäť webových stránok.',
  'what-are-cached' => 'Čo sa ukladajú do pamäte cache?',
  'what-are-cached-help' => 'Generuje 2 typy medzipamäte webových stránok: 1. smerovať medzipamäť, 2. zobraziť medzipamäť. Vyrovnávacia pamäť je veľkým faktorom výkonu webových stránok. Vyrovnávacia pamäť vášho webu výrazne zlepší výkonnosť načítania webových stránok. Viac informácií nájdete v dokumente Laravel doc.',
  'generate-cache' => 'Generovať medzipamäť',
  'clear-cache' => 'Vymazať vyrovnávaciu pamäť',
  'clear-cache-question' => 'Chcete vyčistiť medzipamäť webových stránok?',
  'cache' => 'Cache',
  'not-cached' => 'Webová stránka sa do pamäte cache nenašla.',
  'last-cached-at' => 'Web sa ukladal do medzipamäte',
);