<?php 
return array (
  'seo' => 
  array (
    'edit-paypal' => 'Dashboard - Edit PayPal - :site_name',
  ),
  'alert' => 
  array (
    'value-required' => 'požadovaný',
    'update-paypal-success' => 'Nastavenie PayPal bolo úspešne aktualizované.',
  ),
  'edit-paypal-setting' => 'Upravte platobnú bránu PayPal',
  'edit-paypal-setting-desc' => 'Táto stránka umožňuje povoliť alebo zakázať platobnú bránu PayPal a upraviť nastavenia služby PayPal.',
  'enable-paypal' => 'Povoliť platobnú bránu PayPal',
  'paypal-enabled' => 'PayPal povolený',
  'paypal-disabled' => 'PayPal zakázaný',
  'paypal-sandbox' => 'Pieskovisko',
  'paypal-live' => 'Naživo',
);