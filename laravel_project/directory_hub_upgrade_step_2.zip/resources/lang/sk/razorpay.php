<?php 
return array (
  'alert' => 
  array (
    'invoice-not-found' => 'číslo faktúry sa nenašlo.',
    'invalid-signature' => 'Bol vrátený neplatný podpis razorpay',
    'payment-canceled' => 'Platba bola úspešne zrušená.',
    'razorpay-disable' => 'Razorpay platobná brána zakázaná.',
  ),
  'cancel-payment' => 'Zrušiť platbu',
  'pay-redirect-message' => 'Čakajte prosím ... Otvára sa stránka platby razorpay.',
  'api-key' => 'ID kľúča API',
  'api-secret' => 'Kľúčové slovo API',
  'currency' => 'Mena',
  'currency-help' => 'Ak prijímate inú menu ako indická rupia (INR), najskôr povolte medzinárodnú platbu v službe Razorpay.',
  'webhook' => 'Webhook',
);