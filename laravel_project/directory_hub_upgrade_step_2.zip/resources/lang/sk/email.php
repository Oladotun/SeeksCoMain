<?php
return array (
  'contact' =>
  array (
    'body' =>
    array (
      'body-1' => 'Dostali ste novú kontaktnú správu od :first_name :last_name',
      'body-2' => 'Predmet: :subject',
      'body-3' => 'Od: :first_name :last_name <:email>',
      'body-4' => 'Správa:',
    ),
    'subject' => 'Nová správa kontaktného formulára',
  ),
);
