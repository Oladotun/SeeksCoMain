<?php 
return array (
  'seo' => 
  array (
    'edit' => 'Dashboard - Edit Recaptcha - :site_name',
  ),
  'alert' => 
  array (
    'edit-success' => 'Nastavenie Recaptcha bolo úspešne aktualizované',
    'site-key-required' => 'Ak je povolený jeden alebo viac formulárov, vyžaduje sa kľúč od webu',
    'site-secret-required' => 'Ak je povolený jeden alebo viac formulárov, vyžaduje sa tajomstvo webu',
  ),
  'google-recaptcha' => 'Google reCaptcha verzia 2',
  'google-recaptcha-desc' => 'Táto stránka umožňuje konfigurovať program Google reCaptcha verzie 2 na formulároch webových stránok.',
  'enable-login' => 'Vo formulári na prihlásenie povoľte program Google reCaptcha',
  'enable-sign-up' => 'V registračnom formulári povoľte Google reCaptcha',
  'enable-contact' => 'Povoľte Google reCaptcha v kontaktnom formulári',
  'recaptcha-site-key' => 'Kľúč stránky Google reCaptcha',
  'recaptcha-site-secret' => 'Tajomstvo stránky Google reCaptcha',
  'recaptcha' => 'reCAPTCHA',
);