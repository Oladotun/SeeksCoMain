<?php 
return array (
  'update-url' => 'Aktualizovať URL',
  'alert' => 
  array (
    'item-slug-exist' => 'Webová adresa záznamu existuje, upravte ho na inú adresu.',
    'item-slug-update-success' => 'Adresa URL záznamu bola úspešne aktualizovaná.',
  ),
  'item-slug-help' => 'Adresu URL záznamu môžete zmeniť na adresu URL vhodnú pre SEO. Nezabudnite zadávať iba alfa alebo číselné znaky, pomlčky a podčiarkovníky.',
);