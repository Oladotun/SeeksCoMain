<?php 
return array (
  'delete-custom-field-warning' => 'Odstránením vlastného poľa sa odstránia aj údaje funkcií záznamu, ktoré sú priradené k tomuto vlastnému poľu.',
);