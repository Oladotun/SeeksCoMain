<?php 
return array (
  'alert' => 
  array (
    'bulk-approved' => 'Vybrané záznamy boli úspešne schválené.',
    'bulk-disapproved' => 'Vybrané záznamy boli úspešne zamietnuté.',
    'bulk-suspended' => 'Vybrané záznamy boli úspešne pozastavené.',
    'bulk-deleted' => 'Vybrané záznamy boli úspešne odstránené.',
  ),
  'approve-selected' => 'Schváliť výpisy',
  'disapprove-selected' => 'Zamietnuť záznamy',
  'suspend-selected' => 'Pozastaviť záznamy',
  'delete-selected' => 'Odstrániť záznamy',
  'delete-selected-items-confirm' => 'Chcete odstrániť vybrané záznamy?',
);