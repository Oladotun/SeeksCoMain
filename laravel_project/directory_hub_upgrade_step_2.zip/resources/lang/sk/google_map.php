<?php 
return array (
  'get-directions' => 'Získať smer',
  'google-map' => 'Google Map',
  'map' => 'Mapa',
  'google-map-api-key' => 'Kľúč Google API',
  'open-street-map' => 'OpenStreetMap',
  'select-map' => 'Vyberte možnosť Mapa',
  'select-map-help' => 'Vyberte, ktorá mapa sa má na webe použiť',
  'select-lat-lng-on-map' => 'Kliknutím na mapu získate Lat a Lng',
);