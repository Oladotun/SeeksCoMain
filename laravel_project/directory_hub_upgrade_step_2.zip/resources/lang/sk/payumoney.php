<?php 
return array (
  'seo' => 
  array (
    'edit-payumoney' => 'Dashboard - Upraviť nastavenie Payumoney - :site_name',
  ),
  'alert' => 
  array (
    'payumoney-disable' => 'Platobná brána Payumoney je deaktivovaná.',
    'payment-canceled' => 'Platba Payumoney bola zrušená',
    'invalid-transaction' => 'Neplatná transakcia, skúste to znova.',
    'payment-paid' => 'Platba Payumoney bola úspešne zaplatená',
    'value-required' => 'Požadovaný',
    'updated-success' => 'Nastavenie Payumoney bolo úspešne aktualizované',
  ),
  'pay-redirect-message' => 'Čakajte prosím .. presmerovanie na platobnú stránku Payumoney.',
  'pay-payumoney' => 'Plaťte pomocou Payumoney',
  'edit-payumoney-setting' => 'Upravte platobnú bránu Payumoney',
  'edit-payumoney-setting-desc' => 'Táto stránka umožňuje povoliť alebo zakázať platobnú bránu Payumoney a upraviť nastavenia Payumoney.',
  'enable-payumoney' => 'Povoliť platobnú bránu Payumoney',
  'merchant-key' => 'Obchodný kľúč',
  'merchant-salt' => 'Obchodná soľ',
  'mode' => 'Režim',
  'live' => 'Režim naživo',
  'test' => 'Testovací mód',
  'payumoney-enabled' => 'Payumoney povolené',
  'payumoney-disabled' => 'Payumoney zakázané',
  'payumoney' => 'Payumoney',
);