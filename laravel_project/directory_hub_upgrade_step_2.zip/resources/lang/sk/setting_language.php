<?php 
return array (
  'location' => 
  array (
    'url-slug' => 'Slug URL',
    'url-slug-help' => 'Umožňuje iba alfanumerické alebo číselné znaky, pomlčky a podčiarkovníky.',
    'url-slug-exist' => 'Slimák adresy URL bol prijatý',
  ),
  'language' => 
  array (
    'seo' => 
    array (
      'edit' => 'Panel - nastavenie jazyka - :site_name',
    ),
    'alert' => 
    array (
      'default-not-in-available-languages' => 'Predvolený jazyk, ktorý ste vybrali, sa nenachádza v zozname dostupných jazykov, ktorý ste nastavili',
      'updated-success' => 'Nastavenie jazyka bolo úspešne aktualizované.',
    ),
    'sidebar' => 
    array (
      'language' => 'Jazyk',
    ),
    'language-setting' => 'Nastavenie jazyka',
    'language-setting-desc' => 'Táto stránka umožňuje nastaviť predvolený jazyk webovej stránky a tiež povoliť alebo zakázať dostupné jazyky pre webovú stránku.',
    'available-website-languages' => 'Dostupné jazyky',
    'available-website-languages-help' => 'Môžete povoliť alebo zakázať dostupné jazyky pre webovú stránku.',
  ),
  'country' => 
  array (
    'alert' => 
    array (
      'disable-default-country' => 'Túto krajinu nie je možné zakázať, pretože bola nastavená ako predvolená krajina webových stránok.',
    ),
    'country-status' => 'Postavenie',
    'country-status-help' => 'Zakázaním tejto možnosti zabránite používateľom nastavovať preferencie krajiny v tejto krajine alebo vytvárať zoznamy založené na tejto krajine.',
    'country-status-enable' => 'Povoliť',
    'country-status-disable' => 'Zakázať',
  ),
);