<?php 
return array (
  'image-background-help' => 'Odporučiť minimálny pomer:',
);