<?php 
return array (
  'upload-photos' => 'Nahrajte svoje fotografie',
  'upload-photos-help' => 'Môžete nahrať až 12 fotografií',
  'choose-photo' => 'Vyberte možnosť Fotky',
);