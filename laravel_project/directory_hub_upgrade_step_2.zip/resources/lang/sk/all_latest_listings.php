<?php 
return array (
  'view-all-latest' => 'Zobraziť všetky výpisy',
);