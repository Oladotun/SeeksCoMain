<?php 
return array (
  'oauth-redirect-uri' => 'URI chuyển hướng OAuth',
);