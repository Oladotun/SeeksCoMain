<?php 
return array (
  'image-background-help' => 'Đề xuất tỷ lệ tối thiểu:',
);