<?php 
return array (
  'purchase-button' => 'Mua, tựa vào, bám vào',
  'purchase-desc' => 'Chúng tôi không bán sản phẩm này bên ngoài CodeCanyon. Mua từ tác giả gốc này để được hỗ trợ và cập nhật trọn đời.',
);