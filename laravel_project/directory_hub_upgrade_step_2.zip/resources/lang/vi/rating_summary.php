<?php 
return array (
  '1-stars' => '1 sao',
  '2-stars' => '2 sao',
  '3-stars' => '3 sao',
  '4-stars' => '4 sao',
  '5-stars' => '5 sao',
  'based-on-review' => 'Dựa trên :item_rating_count Nhận xét',
  'based-on-reviews' => 'Dựa trên :item_rating_count Nhận xét',
  'sort-by' => 'Sắp xếp theo',
  'sort-by-newest' => 'Mới nhất đầu tiên',
  'sort-by-oldest' => 'Cũ nhất trước',
  'sort-by-highest' => 'Xếp hạng cao nhất',
  'sort-by-lowest' => 'Xếp hạng thấp nhất',
  'contact' => 'Tiếp xúc',
  'managed-by' => 'Giám đốc',
);