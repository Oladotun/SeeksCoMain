<?php 
return array (
  'update-url' => 'Cập nhật URL',
  'alert' => 
  array (
    'item-slug-exist' => 'URL danh sách tồn tại, vui lòng sửa đổi nó thành một cái gì đó khác.',
    'item-slug-update-success' => 'Đã cập nhật thành công URL danh sách.',
  ),
  'item-slug-help' => 'Bạn có thể thay đổi URL danh sách thành URL thân thiện với SEO. Đảm bảo rằng bạn chỉ nhập các ký tự chữ cái và / hoặc số, dấu gạch ngang và dấu gạch dưới.',
);