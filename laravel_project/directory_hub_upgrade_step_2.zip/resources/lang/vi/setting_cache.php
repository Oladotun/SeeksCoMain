<?php 
return array (
  'seo' => 
  array (
    'edit-setting-cache' => 'Trang tổng quan - Chỉnh sửa bộ nhớ cache - :site_name',
  ),
  'alert' => 
  array (
    'updated-success' => 'Đã tạo bộ nhớ cache của trang web thành công.',
    'deleted-success' => 'Đã xóa bộ nhớ cache của trang web thành công.',
  ),
  'manage-website-cache' => 'Quản lý bộ nhớ cache của trang web',
  'manage-website-cache-desc' => 'Trang này cho phép bạn tạo hoặc xóa bộ nhớ cache của trang web.',
  'what-are-cached' => 'Những gì đang được lưu vào bộ nhớ cache?',
  'what-are-cached-help' => 'Nó tạo ra 2 loại cache của trang web: 1. cache định tuyến, 2. cache xem. Bộ nhớ cache là một yếu tố lớn của hiệu suất trang web, bộ nhớ cache trang web của bạn sẽ cải thiện đáng kể hiệu suất tải trang web. Để biết thêm thông tin, vui lòng tham khảo tài liệu Laravel.',
  'generate-cache' => 'Tạo bộ nhớ đệm',
  'clear-cache' => 'Xóa bộ nhớ cache',
  'clear-cache-question' => 'Bạn có muốn xóa bộ nhớ cache của trang web không?',
  'cache' => 'Bộ nhớ đệm',
  'not-cached' => 'Trang web chưa được lưu trong bộ nhớ cache.',
  'last-cached-at' => 'Trang web được lưu vào bộ nhớ đệm',
);