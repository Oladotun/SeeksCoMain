<?php 
return array (
  'payment' => 'Thanh toán',
  'paypal' => 'PayPal',
  'razorpay' => 'Razorpay',
  'enable-paypal' => 'Bật PayPal',
  'enable-razorpay' => 'Bật Razoray',
  'paypal-ipn' => 'PayPal IPN',
  'pay-paypal' => 'Thanh toán bằng PayPal',
  'pay-razorpay' => 'Thanh toán bằng Razorpay',
  'paypal-disable' => 'Cổng thanh toán PayPal bị vô hiệu hóa.',
);