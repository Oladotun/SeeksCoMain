<?php 
return array (
  'alert' => 
  array (
    'country-delete-error-setting' => 'Quốc gia này là quốc gia mặc định cho trang web, vui lòng chuyển đến Trang tổng quan quản trị&gt; Cài đặt&gt; Chung&gt; Thông tin để thay đổi quốc gia mặc định trước khi xóa.',
    'at-least-one-country' => 'Trang web phải có ít nhất một hồ sơ quốc gia.',
  ),
  'delete-country-warning' => 'Xóa bản ghi quốc gia cũng sẽ xóa tất cả dữ liệu danh sách, tiểu bang và thành phố được liên kết.',
  'delete-state-warning' => 'Xóa hồ sơ tiểu bang cũng sẽ xóa tất cả danh sách liên kết và dữ liệu thành phố.',
  'delete-city-warning' => 'Xóa bản ghi trạng thái cũng sẽ xóa tất cả dữ liệu danh sách liên kết của nó.',
);