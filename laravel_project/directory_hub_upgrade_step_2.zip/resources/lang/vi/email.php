<?php
return array (
  'contact' =>
  array (
    'body' =>
    array (
      'body-1' => 'Bạn đã nhận được một tin nhắn liên hệ mới từ :first_name :last_name',
      'body-2' => 'Chủ đề: :subject',
      'body-3' => 'Từ: :first_name :last_name <:email>',
      'body-4' => 'Thông điệp:',
    ),
    'subject' => 'Thông báo Biểu mẫu Liên hệ Mới',
  ),
);
