<?php 
return array (
  'get-directions' => 'Nhận được hướng dẫn',
  'google-map' => 'Bản đồ Google',
  'map' => 'Bản đồ',
  'google-map-api-key' => 'Khóa API của Google',
  'open-street-map' => 'OpenStreetMap',
  'select-map' => 'Chọn bản đồ',
  'select-map-help' => 'Chọn bản đồ để sử dụng trong trang web',
  'select-lat-lng-on-map' => 'Nhấp vào bản đồ để lấy Lat và Lng',
);