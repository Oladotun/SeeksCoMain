<?php 
return array (
  'alert' => 
  array (
    'instamojo-failed' => 'Thanh toán Instamojo không thành công.',
    'instamojo-success' => 'Thanh toán Instamojo thành công.',
    'instamojo-wrong' => 'Đã xảy ra sự cố với Instamojo',
  ),
);