<?php 
return array (
  'seo' => 
  array (
    'edit-razorpay' => 'Trang tổng quan - Chỉnh sửa Razorpay - :site_name',
  ),
  'alert' => 
  array (
    'value-required' => 'cần thiết',
    'update-razorpay-success' => 'Đã cập nhật thành công cài đặt Razorpay.',
  ),
  'edit-razorpay-setting' => 'Chỉnh sửa cổng thanh toán Razorpay',
  'edit-razorpay-setting-desc' => 'Trang này cho phép bạn bật hoặc tắt cổng thanh toán Razorpay và chỉnh sửa cài đặt Razorpay.',
  'razorpay-enabled' => 'Razorpay Đã bật',
  'razorpay-disabled' => 'Razorpay bị vô hiệu hóa',
  'enable-razorpay' => 'Bật cổng thanh toán Razorpay',
);