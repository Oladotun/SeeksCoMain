<?php 
return array (
  'alert' => 
  array (
    'invoice-not-found' => 'số hóa đơn không được tìm thấy.',
    'invalid-signature' => 'Đã trả lại chữ ký razorpay không hợp lệ',
    'payment-canceled' => 'Đã hủy thanh toán thành công.',
    'razorpay-disable' => 'Cổng thanh toán Razorpay bị vô hiệu hóa.',
  ),
  'cancel-payment' => 'Hủy thanh toán',
  'pay-redirect-message' => 'Vui lòng đợi ... Đang mở trang thanh toán razorpay.',
  'api-key' => 'Id khóa API',
  'api-secret' => 'Bí mật khóa API',
  'currency' => 'Tiền tệ',
  'currency-help' => 'Trước tiên, vui lòng bật thanh toán quốc tế bằng Razorpay nếu bạn chấp nhận đơn vị tiền tệ không phải là rupee Ấn Độ (INR)',
  'webhook' => 'Webhook',
);