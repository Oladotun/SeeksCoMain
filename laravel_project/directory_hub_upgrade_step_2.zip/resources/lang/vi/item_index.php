<?php 
return array (
  'alert' => 
  array (
    'bulk-approved' => 'Danh sách được chọn đã được phê duyệt thành công.',
    'bulk-disapproved' => 'Danh sách được chọn đã bị từ chối thành công.',
    'bulk-suspended' => 'Danh sách được chọn đã bị đình chỉ thành công.',
    'bulk-deleted' => 'Danh sách được chọn đã được xóa thành công.',
  ),
  'approve-selected' => 'Phê duyệt danh sách',
  'disapprove-selected' => 'Từ chối danh sách',
  'suspend-selected' => 'Tạm dừng danh sách',
  'delete-selected' => 'Xóa danh sách',
  'delete-selected-items-confirm' => 'Bạn có muốn xóa danh sách đã chọn không?',
);