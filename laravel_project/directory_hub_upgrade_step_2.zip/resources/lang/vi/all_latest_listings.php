<?php 
return array (
  'view-all-latest' => 'Xem tất cả danh sách',
);