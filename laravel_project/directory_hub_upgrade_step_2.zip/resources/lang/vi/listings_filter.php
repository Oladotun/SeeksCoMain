<?php 
return array (
  'filters' => 'Bộ lọc',
  'categories' => 'Thể loại',
  'sort-by' => 'Sắp xếp theo',
  'update-result' => 'Cập nhật',
  'sort-by-newest' => 'Mới nhất đầu tiên',
  'sort-by-oldest' => 'Cũ nhất trước',
  'sort-by-highest' => 'Xếp hạng cao nhất',
  'sort-by-lowest' => 'Xếp hạng thấp nhất',
  'show-more' => 'Cho xem nhiều hơn',
  'show-less' => 'Hiện ít hơn',
);