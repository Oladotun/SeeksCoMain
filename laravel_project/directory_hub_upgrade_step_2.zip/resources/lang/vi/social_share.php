<?php 
return array (
  'blogger' => 'Blogger',
  'buffer' => 'Đệm',
  'evernote' => 'Evernote',
  'facebook' => 'Facebook',
  'line' => 'Hàng',
  'linkedin' => 'LinkedIn',
  'pinterest' => 'Pinterest',
  'reddit' => 'Reddit',
  'skype' => 'Ứng dụng trò chuyện',
  'telegram' => 'Telegram',
  'twitter' => 'Twitter',
  'viber' => 'Viber',
  'wechat' => 'Wechat',
  'weibo' => 'Weibo',
  'whatsapp' => 'Whatsapp',
  'wordpress' => 'Wordpress',
);