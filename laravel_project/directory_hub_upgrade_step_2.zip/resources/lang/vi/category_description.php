<?php 
return array (
  'category-description' => 'Mô tả danh mục',
  'records' => 'tổng số hồ sơ',
);