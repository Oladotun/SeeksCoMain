<?php 
return array (
  'seo' => 
  array (
    'edit-payumoney' => 'Trang tổng quan - Chỉnh sửa cài đặt Payumoney - :site_name',
  ),
  'alert' => 
  array (
    'payumoney-disable' => 'Cổng thanh toán Payumoney bị vô hiệu hóa.',
    'payment-canceled' => 'Thanh toán qua Payumoney bị hủy',
    'invalid-transaction' => 'Giao dịch không hợp lệ, vui lòng thử lại.',
    'payment-paid' => 'Thanh toán qua Payumoney đã thanh toán thành công',
    'value-required' => 'Cần thiết',
    'updated-success' => 'Đã cập nhật thành công cài đặt Payumoney',
  ),
  'pay-redirect-message' => 'Vui lòng đợi .. chuyển hướng đến trang thanh toán Payumoney.',
  'pay-payumoney' => 'Thanh toán bằng Payumoney',
  'edit-payumoney-setting' => 'Chỉnh sửa cổng thanh toán Payumoney',
  'edit-payumoney-setting-desc' => 'Trang này cho phép bạn bật hoặc tắt cổng thanh toán Payumoney và chỉnh sửa cài đặt Payumoney.',
  'enable-payumoney' => 'Bật cổng thanh toán Payumoney',
  'merchant-key' => 'Khóa người bán',
  'merchant-salt' => 'Muối buôn',
  'mode' => 'Chế độ',
  'live' => 'Chế độ trực tiếp',
  'test' => 'Chê độ kiểm tra',
  'payumoney-enabled' => 'Đã bật Payumoney',
  'payumoney-disabled' => 'Payumoney bị vô hiệu hóa',
  'payumoney' => 'Payumoney',
);