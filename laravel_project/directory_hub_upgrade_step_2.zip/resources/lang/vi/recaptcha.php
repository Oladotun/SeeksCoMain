<?php 
return array (
  'seo' => 
  array (
    'edit' => 'Trang tổng quan - Chỉnh sửa Recaptcha - :site_name',
  ),
  'alert' => 
  array (
    'edit-success' => 'Đã cập nhật thành công cài đặt Recaptcha',
    'site-key-required' => 'Cần có khóa trang web nếu một hoặc nhiều biểu mẫu được bật',
    'site-secret-required' => 'Cần có bí mật trang web nếu một hoặc nhiều biểu mẫu được bật',
  ),
  'google-recaptcha' => 'Google reCaptcha phiên bản 2',
  'google-recaptcha-desc' => 'Trang này cho phép bạn định cấu hình Google reCaptcha phiên bản 2 trên các biểu mẫu trang web.',
  'enable-login' => 'Bật reCaptcha của Google trên biểu mẫu đăng nhập',
  'enable-sign-up' => 'Bật reCaptcha của Google trên biểu mẫu đăng ký',
  'enable-contact' => 'Bật reCaptcha của Google trên biểu mẫu liên hệ',
  'recaptcha-site-key' => 'Khóa trang reCaptcha của Google',
  'recaptcha-site-secret' => 'Google reCaptcha bí mật trang web',
  'recaptcha' => 'reCAPTCHA',
);