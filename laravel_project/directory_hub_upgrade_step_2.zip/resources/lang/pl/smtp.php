<?php 
return array (
  'from-email' => 'Z emaila',
  'from-name' => 'Z nazwy',
  'smtp' => 'SMTP',
  'smtp-enabled' => 'Włącz SMTP',
  'smtp-encryption' => 'Szyfrowanie SMTP',
  'smtp-encryption-null' => 'ZERO',
  'smtp-encryption-ssl' => 'SSL',
  'smtp-encryption-tls' => 'TLS',
  'smtp-host' => 'Host SMTP',
  'smtp-password' => 'Hasło SMTP',
  'smtp-port' => 'Port SMTP',
  'smtp-username' => 'Nazwa użytkownika SMTP',
);