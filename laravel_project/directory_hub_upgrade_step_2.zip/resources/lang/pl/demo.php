<?php 
return array (
  'purchase-button' => 'Zakup',
  'purchase-desc' => 'Nie sprzedajemy tego produktu poza CodeCanyon. Kup od tego oryginalnego autora, aby uzyskać pomoc i dożywotnie aktualizacje.',
);