<?php 
return array (
  'seo' => 
  array (
    'edit' => 'Dashboard - Edytuj Recaptcha - :site_name',
  ),
  'alert' => 
  array (
    'edit-success' => 'Ustawienia Recaptcha zostały zaktualizowane pomyślnie',
    'site-key-required' => 'Klucz witryny jest wymagany, jeśli włączony jest co najmniej jeden formularz',
    'site-secret-required' => 'Sekret witryny jest wymagany, jeśli włączony jest jeden lub więcej formularzy',
  ),
  'google-recaptcha' => 'Google reCaptcha w wersji 2',
  'google-recaptcha-desc' => 'Ta strona umożliwia konfigurację Google reCaptcha w wersji 2 w formularzach witryn internetowych.',
  'enable-login' => 'Włącz Google reCaptcha w formularzu logowania',
  'enable-sign-up' => 'Włącz Google reCaptcha w formularzu rejestracji',
  'enable-contact' => 'Włącz Google reCaptcha w formularzu kontaktowym',
  'recaptcha-site-key' => 'Klucz witryny Google reCaptcha',
  'recaptcha-site-secret' => 'Sekret witryny Google reCaptcha',
  'recaptcha' => 'reCAPTCHA',
);