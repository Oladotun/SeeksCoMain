<?php 
return array (
  'update-url' => 'Zaktualizuj URL',
  'alert' => 
  array (
    'item-slug-exist' => 'Adres URL aukcji istnieje, zmień go na inny.',
    'item-slug-update-success' => 'Adres URL aukcji został zaktualizowany pomyślnie.',
  ),
  'item-slug-help' => 'Możesz zmienić adres URL listy na przyjazny dla SEO. Upewnij się, że wpisujesz tylko znaki alfanumeryczne i / lub cyfry, myślniki i podkreślenia.',
);