<?php 
return array (
  'location' => 
  array (
    'url-slug' => 'błąd adresu URL',
    'url-slug-help' => 'Dopuszcza tylko znaki alfanumeryczne, myślniki i podkreślenia.',
    'url-slug-exist' => 'Ślad adresu URL został pobrany',
  ),
  'language' => 
  array (
    'seo' => 
    array (
      'edit' => 'Pulpit nawigacyjny — ustawienie języka — :site_name',
    ),
    'alert' => 
    array (
      'default-not-in-available-languages' => 'Wybrany język domyślny nie znajduje się na liście dostępnych języków, które ustawiłeś',
      'updated-success' => 'Pomyślnie zaktualizowano ustawienie języka.',
    ),
    'sidebar' => 
    array (
      'language' => 'Język',
    ),
    'language-setting' => 'Ustawienie języka',
    'language-setting-desc' => 'Ta strona pozwala ustawić domyślny język witryny, a także włączyć lub wyłączyć dostępne języki witryny.',
    'available-website-languages' => 'dostępne języki',
    'available-website-languages-help' => 'Możesz włączyć lub wyłączyć dostępne języki dla witryny.',
  ),
  'country' => 
  array (
    'alert' => 
    array (
      'disable-default-country' => 'Nie można wyłączyć tego kraju, ponieważ został on ustawiony jako domyślny kraj witryny.',
    ),
    'country-status' => 'Status',
    'country-status-help' => 'Wyłączenie tej opcji uniemożliwi użytkownikom ustawianie preferencji kraju dla tego kraju lub tworzenie aukcji na podstawie tego kraju.',
    'country-status-enable' => 'Włączyć',
    'country-status-disable' => 'Wyłączyć',
  ),
);