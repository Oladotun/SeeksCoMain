<?php 
return array (
  'oauth-redirect-uri' => 'Identyfikator URI przekierowania OAuth',
);