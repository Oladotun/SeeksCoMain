<?php 
return array (
  'blogger' => 'Blogger',
  'buffer' => 'Bufor',
  'evernote' => 'Evernote',
  'facebook' => 'Facebook',
  'line' => 'Linia',
  'linkedin' => 'LinkedIn',
  'pinterest' => 'Pinterest',
  'reddit' => 'Reddit',
  'skype' => 'Skype',
  'telegram' => 'Telegram',
  'twitter' => 'Świergot',
  'viber' => 'Viber',
  'wechat' => 'Wechat',
  'weibo' => 'Weibo',
  'whatsapp' => 'Whatsapp',
  'wordpress' => 'Wordpress',
);