<?php 
return array (
  '1-stars' => '1 gwiazdki',
  '2-stars' => '2 gwiazdki',
  '3-stars' => '3 gwiazdki',
  '4-stars' => '4 gwiazdki',
  '5-stars' => '5 gwiazdek',
  'based-on-review' => 'Na podstawie przeglądu :item_rating_count',
  'based-on-reviews' => 'Na podstawie 1 recenzji',
  'sort-by' => 'Sortuj według',
  'sort-by-newest' => 'Od najnowszych',
  'sort-by-oldest' => 'Najpierw najstarsi',
  'sort-by-highest' => 'Najwyżej oceniany',
  'sort-by-lowest' => 'Najniższa ocena',
  'contact' => 'Kontakt',
  'managed-by' => 'Menedżer',
);