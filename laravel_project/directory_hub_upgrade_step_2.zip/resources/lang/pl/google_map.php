<?php 
return array (
  'get-directions' => 'Uzyskaj wskazówki',
  'google-map' => 'Mapa Google',
  'map' => 'Mapa',
  'google-map-api-key' => 'Klucz API Google',
  'open-street-map' => 'OpenStreetMap',
  'select-map' => 'Wybierz mapę',
  'select-map-help' => 'Wybierz mapę, której chcesz użyć w witrynie',
  'select-lat-lng-on-map' => 'Kliknij mapę, aby uzyskać Lat i Lng',
);