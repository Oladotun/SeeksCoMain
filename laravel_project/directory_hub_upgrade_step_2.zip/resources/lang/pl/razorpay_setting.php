<?php 
return array (
  'seo' => 
  array (
    'edit-razorpay' => 'Dashboard - Edytuj Razorpay - :site_name',
  ),
  'alert' => 
  array (
    'value-required' => 'wymagany',
    'update-razorpay-success' => 'Ustawienie Razorpay zostało pomyślnie zaktualizowane.',
  ),
  'edit-razorpay-setting' => 'Edytuj bramkę płatności Razorpay',
  'edit-razorpay-setting-desc' => 'Ta strona umożliwia włączanie i wyłączanie bramki płatności Razorpay oraz edycję ustawień Razorpay.',
  'razorpay-enabled' => 'Włączono Razorpay',
  'razorpay-disabled' => 'Razorpay wyłączone',
  'enable-razorpay' => 'Włącz bramkę płatności Razorpay',
);