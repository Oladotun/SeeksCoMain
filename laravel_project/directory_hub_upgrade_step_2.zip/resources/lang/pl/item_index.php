<?php 
return array (
  'alert' => 
  array (
    'bulk-approved' => 'Wybrane aukcje zostały pomyślnie zatwierdzone.',
    'bulk-disapproved' => 'Wybrane wpisy zostały pomyślnie odrzucone.',
    'bulk-suspended' => 'Wybrane aukcje zostały pomyślnie zawieszone.',
    'bulk-deleted' => 'Wybrane aukcje zostały pomyślnie usunięte.',
  ),
  'approve-selected' => 'Zatwierdź aukcje',
  'disapprove-selected' => 'Odrzuć wpisy',
  'suspend-selected' => 'Zawieś aukcje',
  'delete-selected' => 'Usuń aukcje',
  'delete-selected-items-confirm' => 'Czy chcesz usunąć wybrane aukcje?',
);