<?php 
return array (
  'alert' => 
  array (
    'country-delete-error-setting' => 'Ten kraj jest domyślnym krajem dla strony internetowej, przejdź do Pulpit administratora&gt; Ustawienia&gt; Ogólne&gt; Karta Informacje, aby zmienić domyślny kraj przed usunięciem.',
    'at-least-one-country' => 'Witryna musi mieć co najmniej jeden rekord kraju.',
  ),
  'delete-country-warning' => 'Usunięcie rekordu kraju spowoduje również usunięcie wszystkich powiązanych wpisów, stanów i danych miast.',
  'delete-state-warning' => 'Usunięcie rekordu stanu spowoduje również usunięcie wszystkich powiązanych wpisów i danych miast.',
  'delete-city-warning' => 'Usunięcie rekordu stanu spowoduje również usunięcie wszystkich powiązanych danych z aukcji.',
);