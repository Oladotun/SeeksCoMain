<?php 
return array (
  'alert' => 
  array (
    'invoice-not-found' => 'nie znaleziono numeru faktury.',
    'invalid-signature' => 'Zwrócony został nieprawidłowy podpis razorpay',
    'payment-canceled' => 'Płatność anulowana pomyślnie.',
    'razorpay-disable' => 'Bramka płatności Razorpay wyłączona.',
  ),
  'cancel-payment' => 'Anuluj płatność',
  'pay-redirect-message' => 'Proszę czekać ... Otwieram stronę płatności razorpay.',
  'api-key' => 'Identyfikator klucza API',
  'api-secret' => 'Klucz API Secret',
  'currency' => 'Waluta',
  'currency-help' => 'Najpierw włącz płatności międzynarodowe w Razorpay, jeśli akceptujesz walutę inną niż rupia indyjska (INR)',
  'webhook' => 'Webhook',
);