<?php 
return array (
  'image-background-help' => 'Zalecane minimalne proporcje:',
);