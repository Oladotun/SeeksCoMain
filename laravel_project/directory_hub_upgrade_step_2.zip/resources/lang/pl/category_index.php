<?php 
return array (
  'category-name-a-z' => 'Imię AZ',
  'category-name-z-a' => 'Imię ZA',
  'custom-field-name-a-z' => 'Imię AZ',
  'custom-field-name-z-a' => 'Imię ZA',
  'test-smtp' => 
  array (
    'email-subject' => 'Zweryfikuj ten test wysyłania wiadomości e-mail przez SMTP',
    'email-body' => 'To jest testowy e-mail w celu weryfikacji funkcjonalności SMTP. Poniżej znajduje się losowo wygenerowany tekst akapitu.',
    'success-notify' => 'Testowa wiadomość e-mail została pomyślnie wysłana. Sprawdź swoją skrzynkę e-mail lub skrzynkę ze spamem w celu weryfikacji. Informujemy, że testowa wiadomość e-mail została wysłana na adres:',
    'error-notify' => 'Wystąpił błąd podczas wysyłania testowej wiadomości e-mail:',
    'enable-smtp-notify' => 'Włącz SMTP, aby kontynuować test.',
    'send-a-test-email-link' => 'Wyślij testowy e-mail',
    'receiver-email' => 'Adres e-mail odbiorcy',
    'modal' => 
    array (
      'modal-title' => 'Przetestuj ustawienie SMTP',
      'modal-description' => 'Na podany poniżej adres e-mail zostanie wysłany testowy e-mail z podanym ustawieniem SMTP.',
      'modal-send' => 'Wyślij teraz',
    ),
  ),
);