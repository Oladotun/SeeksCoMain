<?php 
return array (
  'alert' => 
  array (
    'instamojo-failed' => 'Płatność Instamojo nie powiodła się.',
    'instamojo-success' => 'Instamojo Płatność powiodła się.',
    'instamojo-wrong' => 'Coś poszło nie tak z Instamojo',
  ),
);