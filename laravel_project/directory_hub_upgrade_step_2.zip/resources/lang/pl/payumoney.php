<?php 
return array (
  'seo' => 
  array (
    'edit-payumoney' => 'Pulpit nawigacyjny - Edytuj ustawienia Payumoney - :site_name',
  ),
  'alert' => 
  array (
    'payumoney-disable' => 'Bramka płatności Payumoney wyłączona.',
    'payment-canceled' => 'Płatność Payumoney została anulowana',
    'invalid-transaction' => 'Nieprawidłowa transakcja, spróbuj ponownie.',
    'payment-paid' => 'Płatność Payumoney została opłacona pomyślnie',
    'value-required' => 'wymagany',
    'updated-success' => 'Zaktualizowano ustawienie Payumoney',
  ),
  'pay-redirect-message' => 'Proszę czekać… przekierowanie do strony płatności Payumoney.',
  'pay-payumoney' => 'Zapłać za pomocą Payumoney',
  'edit-payumoney-setting' => 'Edytuj bramkę płatności Payumoney',
  'edit-payumoney-setting-desc' => 'Ta strona umożliwia włączenie lub wyłączenie bramki płatności Payumoney oraz edycję ustawień Payumoney.',
  'enable-payumoney' => 'Włącz bramkę płatności Payumoney',
  'merchant-key' => 'Klucz sprzedawcy',
  'merchant-salt' => 'Sól kupiecka',
  'mode' => 'Tryb',
  'live' => 'Tryb na żywo',
  'test' => 'Tryb testowy',
  'payumoney-enabled' => 'Włączono Payumoney',
  'payumoney-disabled' => 'Payumoney wyłączone',
  'payumoney' => 'Payumoney',
);