<?php
return array (
  'contact' =>
  array (
    'body' =>
    array (
      'body-1' => 'Otrzymałeś nową wiadomość kontaktową od :first_name :last_name',
      'body-2' => 'Temat: :subject',
      'body-3' => 'Od: :first_name :last_name <:email>',
      'body-4' => 'Wiadomość:',
    ),
    'subject' => 'Nowa wiadomość w formularzu kontaktowym',
  ),
);
