<?php 
return array (
  'seo' => 
  array (
    'edit-paypal' => 'Pulpit nawigacyjny - Edytuj PayPal - :site_name',
  ),
  'alert' => 
  array (
    'value-required' => 'wymagany',
    'update-paypal-success' => 'Ustawienia PayPal zostały pomyślnie zaktualizowane.',
  ),
  'edit-paypal-setting' => 'Edytuj bramkę płatności PayPal',
  'edit-paypal-setting-desc' => 'Ta strona umożliwia włączanie i wyłączanie bramki płatności PayPal oraz edycję ustawień PayPal.',
  'enable-paypal' => 'Włącz bramkę płatności PayPal',
  'paypal-enabled' => 'Włączono PayPal',
  'paypal-disabled' => 'PayPal wyłączony',
  'paypal-sandbox' => 'Piaskownica',
  'paypal-live' => 'Relacja na żywo',
);