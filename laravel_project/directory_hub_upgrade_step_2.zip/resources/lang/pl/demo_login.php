<?php 
return array (
  'demo-login-credentials' => 'Skorzystaj z naszego konta demo do logowania',
  'admin-account' => 'Admin',
  'user-account' => 'Użytkownik',
  'copy-to-login' => 'Kopiuj',
);