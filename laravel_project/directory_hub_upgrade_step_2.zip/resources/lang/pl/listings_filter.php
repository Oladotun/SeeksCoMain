<?php 
return array (
  'filters' => 'Filtry',
  'categories' => 'Kategorie',
  'sort-by' => 'Sortuj według',
  'update-result' => 'Aktualizacja',
  'sort-by-newest' => 'Od najnowszych',
  'sort-by-oldest' => 'Najpierw najstarsi',
  'sort-by-highest' => 'Najwyżej oceniany',
  'sort-by-lowest' => 'Najniższa ocena',
  'show-more' => 'Pokaż więcej',
  'show-less' => 'Pokaż mniej',
);