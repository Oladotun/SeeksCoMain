<?php 
return array (
  'payment' => 'Zapłata',
  'paypal' => 'PayPal',
  'razorpay' => 'Razorpay',
  'enable-paypal' => 'Włącz PayPal',
  'enable-razorpay' => 'Włącz Razoray',
  'paypal-ipn' => 'IPN PayPal',
  'pay-paypal' => 'Zapłać z PayPal-em',
  'pay-razorpay' => 'Zapłać za pomocą Razorpay',
  'paypal-disable' => 'Bramka płatności PayPal jest wyłączona.',
);