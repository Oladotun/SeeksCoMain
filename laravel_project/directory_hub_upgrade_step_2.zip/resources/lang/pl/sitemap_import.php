<?php 
return array (
  'sitemap' => 
  array (
    'state' => 'Stan',
    'city' => 'Miasto',
  ),
  'alert' => 
  array (
    'url-starts-with' => 'URL musi zaczynać się od http:// lub https://',
  ),
  'item-feature-image-url-help' => 'Wpisz adres URL obrazu zaczynający się od http:// lub https://',
  'item-gallery-images-url-help' => 'Wpisz adresy URL obrazów zaczynających się od http:// lub https:// i po jednym wierszu na adres URL',
  'column-item-feature-image' => 'URL obrazu funkcji aukcji',
  'column-item-gallery-images' => 'wyświetlanie adresów URL zdjęć w galerii',
  'csv-file-upload-listing-instruction-columns' => 'Kolumny do wykazu: tytuł, wiadomość (opcja), adres (opcja), miasto, województwo, kraj, szerokość geograficzna (opcja), długość geograficzna (opcja), kod pocztowy, opis, telefon (opcja), strona internetowa (opcja), facebook (opcja) ), twitter (opcja), linkedin (opcja), identyfikator youtube (opcja), adres URL polecanego obrazu (opcja), adresy URL obrazów galerii (opcja).',
  'csv-file-upload-listing-instruction-image-urls' => 'Adresy URL muszą zaczynać się od http:// lub https:// zarówno w kolumnach adresów URL polecanych obrazów, jak i adresów URL obrazów galerii.',
  'csv-file-upload-listing-instruction-gallery-images-urls' => 'W kolumnie Adresy URL obrazów galerii oddziel każdy adres URL obrazu spacją.',
);