<?php 
return array (
  'category-description' => 'Opis kategorii',
  'records' => 'rekordy w sumie',
);