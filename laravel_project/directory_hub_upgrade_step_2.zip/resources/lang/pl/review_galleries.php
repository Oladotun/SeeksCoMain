<?php 
return array (
  'upload-photos' => 'Prześlij swoje zdjęcia',
  'upload-photos-help' => 'Możesz przesłać do 12 zdjęć',
  'choose-photo' => 'Wybierz zdjęcia',
);