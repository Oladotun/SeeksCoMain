<?php 
return array (
  'view-all-latest' => 'Wyświetl wszystkie aukcje',
);