<?php 
return array (
  'seo' => 
  array (
    'edit-setting-cache' => 'Pulpit nawigacyjny - Edytuj pamięć podręczną - :site_name',
  ),
  'alert' => 
  array (
    'updated-success' => 'Pamięć podręczna witryny została pomyślnie wygenerowana.',
    'deleted-success' => 'Pamięć podręczna witryny została pomyślnie wyczyszczona.',
  ),
  'manage-website-cache' => 'Zarządzaj pamięcią podręczną witryny',
  'manage-website-cache-desc' => 'Ta strona umożliwia generowanie lub czyszczenie pamięci podręcznej witryny.',
  'what-are-cached' => 'Co jest buforowane?',
  'what-are-cached-help' => 'Generuje 2 rodzaje pamięci podręcznej witryny: 1. pamięć podręczną tras, 2. pamięć podręczną przeglądania. Pamięć podręczna jest dużym czynnikiem wpływającym na wydajność witryny, buforowanie witryny znacznie poprawi wydajność ładowania witryny. Więcej informacji można znaleźć w dok. Laravel.',
  'generate-cache' => 'Generuj pamięć podręczną',
  'clear-cache' => 'Wyczyść pamięć podręczną',
  'clear-cache-question' => 'Czy chcesz wyczyścić pamięć podręczną witryny?',
  'cache' => 'Pamięć podręczna',
  'not-cached' => 'Witryna nie została zapisana w pamięci podręcznej.',
  'last-cached-at' => 'Witryna jest buforowana',
);