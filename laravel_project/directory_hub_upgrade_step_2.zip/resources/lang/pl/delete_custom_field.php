<?php 
return array (
  'delete-custom-field-warning' => 'Usunięcie pola niestandardowego spowoduje również usunięcie danych funkcji aukcji powiązanych z tym polem niestandardowym.',
);