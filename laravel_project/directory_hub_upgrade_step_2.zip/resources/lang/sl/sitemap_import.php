<?php 
return array (
  'sitemap' => 
  array (
    'state' => 'Država',
    'city' => 'Mesto',
  ),
  'alert' => 
  array (
    'url-starts-with' => 'URL se mora začeti s http: // ali https: //',
  ),
  'item-feature-image-url-help' => 'URL za vnos slike se začne s http: // ali https: //',
  'item-gallery-images-url-help' => 'Vnos URL-jev slik se začne s http: // ali https: // in eno vrstico na URL',
  'column-item-feature-image' => 'navedba URL-ja slike funkcije',
  'column-item-gallery-images' => 'seznam URL-jev slik v galeriji',
  'csv-file-upload-listing-instruction-columns' => 'Stolpci za seznam: naslov, polž (možnost), naslov (možnost), mesto, država, država, zemljepisna širina (možnost), zemljepisna dolžina (možnost), poštna številka, opis, telefon (možnost), spletno mesto (možnost), facebook (možnost ), twitter (možnost), linkedin (možnost), YouTube ID (možnost), URL predstavljene slike (možnost), URL-ji slik galerije (možnost).',
  'csv-file-upload-listing-instruction-image-urls' => 'URL-ji se morajo začeti s http: // ali https: // v stolpcih URL-jev predstavljene slike in URL-jev galerijskih slik.',
  'csv-file-upload-listing-instruction-gallery-images-urls' => 'V stolpcu URL-ji slik galerije ločite vsak URL slike s presledki.',
);