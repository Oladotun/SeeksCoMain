<?php 
return array (
  'get-directions' => 'Pridobite navodila',
  'google-map' => 'Google zemljevid',
  'map' => 'Zemljevid',
  'google-map-api-key' => 'Ključ Google API',
  'open-street-map' => 'OpenStreetMap',
  'select-map' => 'Izberite Zemljevid',
  'select-map-help' => 'Izberite zemljevid, ki ga želite uporabiti na spletnem mestu',
  'select-lat-lng-on-map' => 'Kliknite zemljevid, da dobite Lat in Lng',
);