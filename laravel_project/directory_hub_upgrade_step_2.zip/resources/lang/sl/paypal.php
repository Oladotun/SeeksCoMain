<?php 
return array (
  'seo' => 
  array (
    'edit-paypal' => 'Nadzorna plošča - Uredi PayPal - :site_name',
  ),
  'alert' => 
  array (
    'value-required' => 'zahteva',
    'update-paypal-success' => 'Nastavitev PayPal je bila uspešno posodobljena.',
  ),
  'edit-paypal-setting' => 'Uredi plačilni prehod PayPal',
  'edit-paypal-setting-desc' => 'Na tej strani lahko omogočite ali onemogočite plačilni prehod PayPal in uredite nastavitve PayPal.',
  'enable-paypal' => 'Omogoči plačilni prehod PayPal',
  'paypal-enabled' => 'PayPal omogočen',
  'paypal-disabled' => 'PayPal je onemogočen',
  'paypal-sandbox' => 'Peskovnik',
  'paypal-live' => 'V živo',
);