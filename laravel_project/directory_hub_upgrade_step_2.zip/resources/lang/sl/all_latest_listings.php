<?php 
return array (
  'view-all-latest' => 'Ogled vseh seznamov',
);