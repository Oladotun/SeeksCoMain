<?php 
return array (
  'blogger' => 'Bloger',
  'buffer' => 'Odbojnik',
  'evernote' => 'Evernote',
  'facebook' => 'Facebook',
  'line' => 'Vrstica',
  'linkedin' => 'LinkedIn',
  'pinterest' => 'Pinterest',
  'reddit' => 'Reddit',
  'skype' => 'Skype',
  'telegram' => 'Telegram',
  'twitter' => 'Twitter',
  'viber' => 'Viber',
  'wechat' => 'Wechat',
  'weibo' => 'Weibo',
  'whatsapp' => 'Whatsapp',
  'wordpress' => 'Wordpress',
);