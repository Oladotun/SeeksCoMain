<?php 
return array (
  'seo' => 
  array (
    'edit-setting-cache' => 'Nadzorna plošča - Uredi predpomnilnik - :site_name',
  ),
  'alert' => 
  array (
    'updated-success' => 'Predpomnilnik spletnega mesta je bil uspešno ustvarjen.',
    'deleted-success' => 'Predpomnilnik spletnega mesta je bil uspešno očiščen.',
  ),
  'manage-website-cache' => 'Upravljanje predpomnilnika spletnih mest',
  'manage-website-cache-desc' => 'Na tej strani lahko ustvarite ali počistite predpomnilnik spletnega mesta.',
  'what-are-cached' => 'Kaj se shranjuje v predpomnilnik?',
  'what-are-cached-help' => 'Ustvari 2 vrsti predpomnilnika spletnih mest: 1. predpomnilnik poti, 2. pogled predpomnilnika. Predpomnilnik je velik dejavnik uspešnosti spletnega mesta, predpomnilnik vašega spletnega mesta bo znatno izboljšal zmogljivost nalaganja spletnega mesta. Za več informacij glejte dokument Laravel.',
  'generate-cache' => 'Ustvari predpomnilnik',
  'clear-cache' => 'Počistiti začasni pomnilnik',
  'clear-cache-question' => 'Ali želite počistiti predpomnilnik spletnega mesta?',
  'cache' => 'predpomnilnik',
  'not-cached' => 'Spletno mesto ni predpomnjeno.',
  'last-cached-at' => 'Spletno mesto je bilo predpomnjeno',
);