<?php 
return array (
  'seo' => 
  array (
    'edit-razorpay' => 'Nadzorna plošča - Uredi Razorpay - :site_name',
  ),
  'alert' => 
  array (
    'value-required' => 'zahteva',
    'update-razorpay-success' => 'Nastavitev storitve Razorpay je bila uspešno posodobljena.',
  ),
  'edit-razorpay-setting' => 'Uredi plačilni prehod Razorpay',
  'edit-razorpay-setting-desc' => 'Na tej strani lahko omogočite ali onemogočite plačilni prehod Razorpay in uredite nastavitve Razorpay.',
  'razorpay-enabled' => 'Razorpay omogočeno',
  'razorpay-disabled' => 'Razorpay onemogočen',
  'enable-razorpay' => 'Omogočite plačilni prehod Razorpay',
);