<?php
return array (
  'contact' =>
  array (
    'body' =>
    array (
      'body-1' => 'Prejeli ste novo kontaktno sporočilo od :first_name :last_name',
      'body-2' => 'Zadeva: :subject',
      'body-3' => 'Od: :first_name :last_name <:email>',
      'body-4' => 'Sporočilo:',
    ),
    'subject' => 'Novo sporočilo za kontaktni obrazec',
  ),
);
