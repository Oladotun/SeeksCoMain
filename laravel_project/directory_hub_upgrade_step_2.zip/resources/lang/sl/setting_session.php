<?php 
return array (
  'seo' => 
  array (
    'edit-setting-session' => 'Nadzorna plošča - Uredi sejo - :site_name',
  ),
  'alert' => 
  array (
    'session-updated-success' => 'Nastavitev seje je bila uspešno posodobljena.',
  ),
  'edit' => 'Nastavitev seje',
  'edit-desc' => 'Na tej strani lahko konfigurirate sejo spletnega mesta',
  'session-file' => 'mapa',
  'session-cookie' => 'Piškotek',
  'session-database' => 'Zbirka podatkov',
  'session-driver' => 'Voznik seje',
  'session' => 'Seja',
  'update-help' => 'Po posodobitvi gonilnika seje se morate znova prijaviti',
  'session-intro-desc' => 'Ker aplikacije, ki jih poganja HTTP, nimajo stanja, seje omogočajo shranjevanje informacij o uporabniku v več zahtevah. Spletno mesto podpira 3 načine shranjevanja informacij o sejah: datoteko, piškotek in bazo podatkov. Ne glede na način shranjevanja seje so informacije o seji šifrirane.',
  'session-file-help' => 'Datoteka - seje so shranjene v laravel_project / storage / framework / session.',
  'session-cookie-help' => 'Piškotek - seje so shranjene v varnih, šifriranih piškotkih.',
  'session-database-help' => 'Baza podatkov - seje so shranjene v tabeli sej baze podatkov spletnega mesta.',
);