<?php 
return array (
  'location' => 
  array (
    'url-slug' => 'URL polž',
    'url-slug-help' => 'Omogoča samo alfa in / ali številske znake, pomišljaje in podčrtaje.',
    'url-slug-exist' => 'Urg polž je bil zajet',
  ),
  'language' => 
  array (
    'seo' => 
    array (
      'edit' => 'Nadzorna plošča - Nastavitev jezika - :site_name',
    ),
    'alert' => 
    array (
      'default-not-in-available-languages' => 'Privzeti jezik, ki ste ga izbrali, ni na seznamu razpoložljivih jezikov, ki ste jih nastavili',
      'updated-success' => 'Nastavitev jezika je bila uspešno posodobljena.',
    ),
    'sidebar' => 
    array (
      'language' => 'Jezik',
    ),
    'language-setting' => 'Nastavitev jezika',
    'language-setting-desc' => 'Na tej strani lahko nastavite privzeti jezik spletnega mesta ter omogočite ali onemogočite jezike, ki so na voljo za spletno mesto.',
    'available-website-languages' => 'Razpoložljivi jeziki',
    'available-website-languages-help' => 'Razpoložljive jezike spletnega mesta lahko omogočite ali onemogočite.',
  ),
  'country' => 
  array (
    'alert' => 
    array (
      'disable-default-country' => 'Te države ni mogoče onemogočiti, ker je bila nastavljena kot privzeta država spletnega mesta.',
    ),
    'country-status' => 'Stanje',
    'country-status-help' => 'Če to onemogočite, uporabniki ne bodo mogli določiti nastavitve države za to državo ali ustvarjati seznamov na podlagi te države.',
    'country-status-enable' => 'Omogoči',
    'country-status-disable' => 'Onemogoči',
  ),
);