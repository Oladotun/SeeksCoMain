<?php 
return array (
  'oauth-redirect-uri' => 'URI preusmeritve OAuth',
);