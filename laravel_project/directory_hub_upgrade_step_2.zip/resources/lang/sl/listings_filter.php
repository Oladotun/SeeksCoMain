<?php 
return array (
  'filters' => 'Filtri',
  'categories' => 'Kategorije',
  'sort-by' => 'Razvrsti po',
  'update-result' => 'Nadgradnja',
  'sort-by-newest' => 'Najnovejše najprej',
  'sort-by-oldest' => 'Najstarejši najprej',
  'sort-by-highest' => 'Najvišje ocenjeno',
  'sort-by-lowest' => 'Najnižja ocena',
  'show-more' => 'Pokaži več',
  'show-less' => 'Pokaži manj',
);