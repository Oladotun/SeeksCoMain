<?php 
return array (
  'demo-login-credentials' => 'Za prijavo uporabite naš predstavitveni račun',
  'admin-account' => 'Skrbnik',
  'user-account' => 'Uporabnik',
  'copy-to-login' => 'Kopirati',
);