<?php 
return array (
  'delete-custom-field-warning' => 'Če izbrišete polje po meri, bodo izbrisani tudi podatki o funkcijah seznama, povezani s tem poljem po meri.',
);