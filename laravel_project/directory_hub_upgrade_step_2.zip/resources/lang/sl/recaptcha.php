<?php 
return array (
  'seo' => 
  array (
    'edit' => 'Nadzorna plošča - Uredi ponovitev - :site_name',
  ),
  'alert' => 
  array (
    'edit-success' => 'Nastavitev ponovitve je uspešno posodobljena',
    'site-key-required' => 'Ključ mesta je potreben, če je omogočen eden ali več obrazcev',
    'site-secret-required' => 'Skrivnost spletnega mesta je potrebna, če je omogočen eden ali več obrazcev',
  ),
  'google-recaptcha' => 'Google reCaptcha, različica 2',
  'google-recaptcha-desc' => 'Ta stran vam omogoča, da na obrazcih spletnega mesta nastavite različico Google reCaptcha različice 2.',
  'enable-login' => 'Na obrazcu za prijavo omogočite Google reCaptcha',
  'enable-sign-up' => 'Na obrazcu za prijavo omogočite Google reCaptcha',
  'enable-contact' => 'V obrazcu za stik omogočite Google reCaptcha',
  'recaptcha-site-key' => 'Ključ spletnega mesta Google reCaptcha',
  'recaptcha-site-secret' => 'Skrivnost spletnega mesta Google reCaptcha',
  'recaptcha' => 'reCAPTCHA',
);