<?php 
return array (
  'alert' => 
  array (
    'instamojo-failed' => 'Plačilo Instamojo ni uspelo.',
    'instamojo-success' => 'Uspeh plačila Instamojo.',
    'instamojo-wrong' => 'Nekaj je šlo narobe z Instamojo',
  ),
);