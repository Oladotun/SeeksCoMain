<?php 
return array (
  'payment' => 'Plačilo',
  'paypal' => 'PayPal',
  'razorpay' => 'Razorpay',
  'enable-paypal' => 'Omogoči PayPal',
  'enable-razorpay' => 'Omogoči Razoray',
  'paypal-ipn' => 'PayPal IPN',
  'pay-paypal' => 'Plačajte s PayPal',
  'pay-razorpay' => 'Plačajte z Razorpay',
  'paypal-disable' => 'Plačilni prehod PayPal je onemogočen.',
);