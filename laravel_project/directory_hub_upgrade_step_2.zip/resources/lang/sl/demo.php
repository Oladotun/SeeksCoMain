<?php 
return array (
  'purchase-button' => 'Nakup',
  'purchase-desc' => 'Tega izdelka ne prodajamo zunaj CodeCanyon-a. Nakup od tega izvirnega avtorja za podporo in življenjske posodobitve.',
);