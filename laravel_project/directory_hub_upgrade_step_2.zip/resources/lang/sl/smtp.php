<?php 
return array (
  'from-email' => 'Iz e-pošte',
  'from-name' => 'Od imena',
  'smtp' => 'SMTP',
  'smtp-enabled' => 'Omogoči SMTP',
  'smtp-encryption' => 'Šifriranje SMTP',
  'smtp-encryption-null' => 'NIČ',
  'smtp-encryption-ssl' => 'SSL',
  'smtp-encryption-tls' => 'TLS',
  'smtp-host' => 'SMTP gostitelj',
  'smtp-password' => 'Geslo SMTP',
  'smtp-port' => 'Vrata SMTP',
  'smtp-username' => 'Uporabniško ime SMTP',
);