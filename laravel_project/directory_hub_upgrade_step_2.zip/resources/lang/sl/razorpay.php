<?php 
return array (
  'alert' => 
  array (
    'invoice-not-found' => 'številke računa ni mogoče najti.',
    'invalid-signature' => 'Vrnjen je neveljaven podpis razorpay',
    'payment-canceled' => 'Plačilo je bilo uspešno preklicano.',
    'razorpay-disable' => 'Prehod za plačilo Razorpay je onemogočen.',
  ),
  'cancel-payment' => 'Prekliči plačilo',
  'pay-redirect-message' => 'Počakajte ... Odpiranje strani za plačilo z razorpay.',
  'api-key' => 'ID ključa API',
  'api-secret' => 'Ključna skrivnost API-ja',
  'currency' => 'Valuta',
  'currency-help' => 'Najprej omogočite mednarodno plačilo v Razorpay, če sprejemate valuto, ki ni indijska rupija (INR)',
  'webhook' => 'Spletni kavelj',
);