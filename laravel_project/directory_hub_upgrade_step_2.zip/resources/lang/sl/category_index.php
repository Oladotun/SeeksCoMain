<?php 
return array (
  'category-name-a-z' => 'Ime AZ',
  'category-name-z-a' => 'Ime ZA',
  'custom-field-name-a-z' => 'Ime AZ',
  'custom-field-name-z-a' => 'Ime ZA',
  'test-smtp' => 
  array (
    'email-subject' => 'Preverite ta test pošiljanja e -pošte prek SMTP',
    'email-body' => 'To je testno e -poštno sporočilo za preverjanje funkcionalnosti SMTP. Sledi naključno ustvarjeno besedilo odstavka.',
    'success-notify' => 'Preizkusno e -poštno sporočilo je bilo uspešno poslano. Za preverjanje preverite e -poštni predal ali vsiljeno pošto. Za vašo informacijo je bilo testno e -poštno sporočilo poslano na:',
    'error-notify' => 'Pri pošiljanju preskusnega e -poštnega sporočila je prišlo do napake:',
    'enable-smtp-notify' => 'Če želite nadaljevati s preskusom, omogočite SMTP.',
    'send-a-test-email-link' => 'Pošljite testno e -pošto',
    'receiver-email' => 'E -pošta prejemnika',
    'modal' => 
    array (
      'modal-title' => 'Preizkusite nastavitve SMTP',
      'modal-description' => 'Na spodnji e -poštni naslov, ki ste ga vnesli, bo poslano preskusno e -poštno sporočilo z nastavitvijo SMTP, ki ste jo vnesli.',
      'modal-send' => 'Pošlji zdaj',
    ),
  ),
);