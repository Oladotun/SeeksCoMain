<?php 
return array (
  'category-description' => 'Opis kategorije',
  'records' => 'zapisov skupaj',
);