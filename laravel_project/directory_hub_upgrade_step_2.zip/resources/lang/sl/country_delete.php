<?php 
return array (
  'alert' => 
  array (
    'country-delete-error-setting' => 'Ta država je privzeta država za spletno mesto, pojdite na Nadzorna plošča za skrbnike&gt; Nastavitve&gt; Splošno&gt; Zavihek Informacije, da spremenite privzeto državo pred brisanjem.',
    'at-least-one-country' => 'Spletno mesto mora imeti vsaj en zapis o državi.',
  ),
  'delete-country-warning' => 'Izbriši zapis države bo odstranil tudi vse sezname pridruženih držav, države in mesta.',
  'delete-state-warning' => 'Izbriši državni zapis bo odstranil tudi vse sezname pridruženih podjetij in podatke o mestih.',
  'delete-city-warning' => 'Izbriši državni zapis bo odstranil tudi vse podatke o njegovih povezanih seznamih.',
);