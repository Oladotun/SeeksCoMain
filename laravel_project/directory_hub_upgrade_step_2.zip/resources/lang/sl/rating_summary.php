<?php 
return array (
  '1-stars' => '1 zvezde',
  '2-stars' => '2 zvezdici',
  '3-stars' => '3 zvezdice',
  '4-stars' => '4 zvezdice',
  '5-stars' => '5 zvezdic',
  'based-on-review' => 'Na podlagi pregleda :item_rating_count',
  'based-on-reviews' => 'Na podlagi :item_rating_count ocen',
  'sort-by' => 'Razvrsti po',
  'sort-by-newest' => 'Najnovejše najprej',
  'sort-by-oldest' => 'Najstarejši najprej',
  'sort-by-highest' => 'Najvišje ocenjeno',
  'sort-by-lowest' => 'Najnižja ocena',
  'contact' => 'Kontakt',
  'managed-by' => 'Manager',
);