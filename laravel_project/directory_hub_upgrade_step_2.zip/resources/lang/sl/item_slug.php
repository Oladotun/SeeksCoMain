<?php 
return array (
  'update-url' => 'Posodobi URL',
  'alert' => 
  array (
    'item-slug-exist' => 'URL vnosa obstaja, spremenite ga v kaj drugega.',
    'item-slug-update-success' => 'URL vnosa je bil uspešno posodobljen.',
  ),
  'item-slug-help' => 'URL vnosa lahko spremenite v SEO prijazen URL. Prepričajte se, da ste vnesli samo alfa in / ali številske znake, pomišljaje in podčrtaje.',
);