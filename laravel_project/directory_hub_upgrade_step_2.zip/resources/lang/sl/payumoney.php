<?php 
return array (
  'seo' => 
  array (
    'edit-payumoney' => 'Nadzorna plošča - Uredi nastavitev Payumoney - :site_name',
  ),
  'alert' => 
  array (
    'payumoney-disable' => 'Plačilni prehod Payumoney je onemogočen.',
    'payment-canceled' => 'Payumoney plačilo preklicano',
    'invalid-transaction' => 'Neveljavna transakcija, poskusite znova.',
    'payment-paid' => 'Payumoney plačilo je bilo uspešno plačano',
    'value-required' => 'Obvezno',
    'updated-success' => 'Nastavitev Payumoney je bila uspešno posodobljena',
  ),
  'pay-redirect-message' => 'Počakajte .. preusmeritev na plačilno stran Payumoney.',
  'pay-payumoney' => 'Plačajte s Payumoney',
  'edit-payumoney-setting' => 'Uredi plačilni prehod Payumoney',
  'edit-payumoney-setting-desc' => 'Na tej strani lahko omogočite ali onemogočite plačilni prehod Payumoney in uredite nastavitve Payumoney.',
  'enable-payumoney' => 'Omogočite plačilni prehod Payumoney',
  'merchant-key' => 'Trgovski ključ',
  'merchant-salt' => 'Trgovska sol',
  'mode' => 'Način',
  'live' => 'Način v živo',
  'test' => 'Testni način',
  'payumoney-enabled' => 'Payumoney omogočen',
  'payumoney-disabled' => 'Payumoney je onemogočen',
  'payumoney' => 'Payumoney',
);