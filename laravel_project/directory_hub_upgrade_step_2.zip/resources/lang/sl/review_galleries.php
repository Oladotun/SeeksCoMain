<?php 
return array (
  'upload-photos' => 'Naložite svoje fotografije',
  'upload-photos-help' => 'Naložite lahko do 12 fotografij',
  'choose-photo' => 'Izberite Fotografije',
);