<?php 
return array (
  'image-background-help' => 'Priporočite minimalno razmerje:',
);