<?php 
return array (
  'alert' => 
  array (
    'bulk-approved' => 'Izbrani oglasi so bili uspešno odobreni.',
    'bulk-disapproved' => 'Izbrani oglasi so bili uspešno zavrnjeni.',
    'bulk-suspended' => 'Izbrani oglasi so bili uspešno zaustavljeni.',
    'bulk-deleted' => 'Izbrani oglasi so bili uspešno izbrisani.',
  ),
  'approve-selected' => 'Odobrite sezname',
  'disapprove-selected' => 'Neodobri seznamov',
  'suspend-selected' => 'Začasno ustavi seznam',
  'delete-selected' => 'Izbriši sezname',
  'delete-selected-items-confirm' => 'Ali želite izbrisati izbrane sezname?',
);