<?php 
return array (
  'category-name-a-z' => 'AZ nomi',
  'category-name-z-a' => 'Ismi ZA',
  'custom-field-name-a-z' => 'AZ nomi',
  'custom-field-name-z-a' => 'Ismi ZA',
  'test-smtp' => 
  array (
    'email-subject' => 'SMTP orqali elektron pochta yuborish testini tasdiqlang',
    'email-body' => 'Bu SMTP funksionalligini tekshirish uchun elektron pochta. Quyida tasodifiy yaratilgan paragraf matni keltirilgan.',
    'success-notify' => 'Test elektron pochtasi muvaffaqiyatli yuborildi. Tasdiqlash uchun elektron pochta qutingizga yoki spam qutisiga belgi qo&#39;ying. Sizning ma&#39;lumotingiz uchun test elektron pochtasi yuborilgan:',
    'error-notify' => 'Sinov xatini yuborishda xatolik yuz berdi:',
    'enable-smtp-notify' => 'Sinovni davom ettirish uchun SMTP -ni yoqing.',
    'send-a-test-email-link' => 'Sinov xatini yuboring',
    'receiver-email' => 'Qabul qiluvchi elektron pochta',
    'modal' => 
    array (
      'modal-title' => 'SMTP sozlamalarini sinab ko&#39;rish',
      'modal-description' => 'Siz ko&#39;rsatgan SMTP sozlamasi bilan siz kiritgan elektron pochta manziliga test xat yuboriladi.',
      'modal-send' => 'Hozir yuboring',
    ),
  ),
);