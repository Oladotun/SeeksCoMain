<?php
return array (
  'alert' =>
  array (
    'invoice-not-found' => 'hisob-faktura raqami topilmadi.',
    'invalid-signature' => 'Noto\'g\'ri razorpay imzosi qaytarildi',
    'payment-canceled' => 'To‘lov bekor qilindi.',
    'razorpay-disable' => 'Razorpay to\'lov shlyuzi o\'chirilgan.',
  ),
  'cancel-payment' => 'To\'lovni bekor qilish',
  'pay-redirect-message' => 'Iltimos, kuting ... Razorpay to\'lov sahifasi ochilmoqda.',
  'api-key' => 'API kalit identifikatori',
  'api-secret' => 'API kalit sirlari',
  'currency' => 'Valyuta',
  'currency-help' => 'Iltimos, hind rupisidan (INR) boshqa valyutani qabul qilsangiz, avval Razorpayda xalqaro to\'lovni yoqing.',
  'webhook' => 'Webhook',
);
