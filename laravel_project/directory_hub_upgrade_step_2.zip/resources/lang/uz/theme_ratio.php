<?php 
return array (
  'image-background-help' => 'Minimal nisbatni tavsiya eting:',
);