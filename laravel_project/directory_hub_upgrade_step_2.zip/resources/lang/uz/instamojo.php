<?php
return array (
  'alert' =>
  array (
    'instamojo-failed' => 'Instamojo orqali to\'lov amalga oshmadi.',
    'instamojo-success' => 'Instamojo to\'lovi muvaffaqiyatli bo\'ldi.',
    'instamojo-wrong' => 'Instamojo bilan xatolik yuz berdi',
  ),
);
