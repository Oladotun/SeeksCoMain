<?php
return array (
  'seo' =>
  array (
    'edit' => 'Boshqarish paneli - Recaptcha-ni tahrirlash - :site_name',
  ),
  'alert' =>
  array (
    'edit-success' => 'Recaptcha sozlamasi muvaffaqiyatli yangilandi',
    'site-key-required' => 'Agar bitta yoki bir nechta shakl yoqilgan bo\'lsa, sayt kaliti talab qilinadi',
    'site-secret-required' => 'Agar bitta yoki bir nechta shakl yoqilgan bo\'lsa, sayt siri talab qilinadi',
  ),
  'google-recaptcha' => 'Google reCaptcha 2-versiyasi',
  'google-recaptcha-desc' => 'Ushbu sahifa veb-sayt shakllarida Google reCaptcha 2-versiyasini sozlash imkonini beradi.',
  'enable-login' => 'Kirish formasida Google reCaptcha-ni yoqing',
  'enable-sign-up' => 'Ro\'yxatdan o\'tish formasida Google reCaptcha-ni yoqing',
  'enable-contact' => 'Aloqa formasida Google reCaptcha-ni yoqing',
  'recaptcha-site-key' => 'Google reCaptcha sayt kaliti',
  'recaptcha-site-secret' => 'Google reCaptcha saytining siri',
  'recaptcha' => 'reCAPTCHA',
);
