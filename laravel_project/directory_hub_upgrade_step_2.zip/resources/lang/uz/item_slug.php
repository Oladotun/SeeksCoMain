<?php
return array (
  'update-url' => 'URL manzilini yangilang',
  'alert' =>
  array (
    'item-slug-exist' => 'Ro\'yxat URL manzili mavjud, iltimos, uni boshqa joyga o\'zgartiring.',
    'item-slug-update-success' => 'Ro\'yxat URL manzili muvaffaqiyatli yangilandi.',
  ),
  'item-slug-help' => 'Siz ro\'yxat URL-ni SEO bilan do\'st URL-ga o\'zgartirishingiz mumkin. Faqat alfa va / yoki raqamli belgilar, chiziqcha va pastki chiziqlarni kiritganingizga ishonch hosil qiling.',
);
