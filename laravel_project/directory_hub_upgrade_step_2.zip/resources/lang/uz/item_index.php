<?php
return array (
  'alert' =>
  array (
    'bulk-approved' => 'Tanlangan ro\'yxatlar muvaffaqiyatli tasdiqlandi.',
    'bulk-disapproved' => 'Tanlangan ro\'yxatlar muvaffaqiyatli tasdiqlanmadi.',
    'bulk-suspended' => 'Tanlangan ro\'yxatlar muvaffaqiyatli to\'xtatildi.',
    'bulk-deleted' => 'Tanlangan ro\'yxatlar muvaffaqiyatli o\'chirildi.',
  ),
  'approve-selected' => 'Ro\'yxatlarni tasdiqlash',
  'disapprove-selected' => 'Ro\'yxatlarni rad etaman',
  'suspend-selected' => 'Listinglarni to\'xtatib turish',
  'delete-selected' => 'Ro\'yxatlarni o\'chirish',
  'delete-selected-items-confirm' => 'Tanlangan ro\'yxatlarni o\'chirishni xohlaysizmi?',
);
