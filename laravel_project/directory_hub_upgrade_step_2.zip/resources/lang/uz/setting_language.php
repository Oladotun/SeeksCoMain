<?php 
return array (
  'location' => 
  array (
    'url-slug' => 'URL slug',
    'url-slug-help' => 'Faqat alfa va / yoki raqamli belgilar, chiziqcha va pastki chiziqlarga ruxsat beradi.',
    'url-slug-exist' => 'Url slug olingan',
  ),
  'language' => 
  array (
    'seo' => 
    array (
      'edit' => 'Boshqarish paneli - Til sozlamalari - :site_name',
    ),
    'alert' => 
    array (
      'default-not-in-available-languages' => 'Siz tanlagan standart til siz o&#39;rnatgan mavjud tillar ro&#39;yxatida yo&#39;q',
      'updated-success' => 'Til sozlamalari muvaffaqiyatli yangilandi.',
    ),
    'sidebar' => 
    array (
      'language' => 'Til',
    ),
    'language-setting' => 'Til sozlamalari',
    'language-setting-desc' => 'Ushbu sahifa veb-saytning standart tilini o&#39;rnatishga, shuningdek veb-sayt uchun mavjud tillarni yoqishga yoki o&#39;chirishga imkon beradi.',
    'available-website-languages' => 'Mavjud tillar',
    'available-website-languages-help' => 'Veb-sayt uchun mavjud tillarni yoqishingiz yoki o&#39;chirib qo&#39;yishingiz mumkin.',
  ),
  'country' => 
  array (
    'alert' => 
    array (
      'disable-default-country' => 'Ushbu mamlakatni o&#39;chirib bo&#39;lmaydi, chunki u veb-sayt standart mamlakat sifatida o&#39;rnatilgan.',
    ),
    'country-status' => 'Holat',
    'country-status-help' => 'O&#39;chirib qo&#39;yilsa, foydalanuvchilar ushbu mamlakatning mamlakat parametrlarini belgilashlari yoki ushbu mamlakat asosida ro&#39;yxat tuzishlariga yo&#39;l qo&#39;ymaydi.',
    'country-status-enable' => 'Yoqish',
    'country-status-disable' => 'O&#39;chirish',
  ),
);