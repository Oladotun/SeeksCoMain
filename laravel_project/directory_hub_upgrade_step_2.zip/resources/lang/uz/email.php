<?php
return array (
  'contact' =>
  array (
    'body' =>
    array (
      'body-1' => 'Siz :first_name :last_name raqamidan yangi aloqa xabarini oldingiz',
      'body-2' => 'Mavzu: :subject',
      'body-3' => 'Kimdan: :first_name :last_name <:email>',
      'body-4' => 'Xabar:',
    ),
    'subject' => 'Yangi aloqa shakli haqidagi xabar',
  ),
);
