<?php
return array (
  'alert' =>
  array (
    'sync-restore-success' => 'Barcha til fayllari muvaffaqiyatli tiklandi.',
    'sync-success' => 'Barcha til fayllari ma\'lumotlar bazasiga muvaffaqiyatli sinxronlanadi.',
  ),
  'edit-lang' => 'Tillarni tahrirlash',
  'sync-button' => 'Endi sinxronlashtiring',
  'sync-desc' => 'Ushbu sahifa barcha tillardagi fayllarni ma\'lumotlar bazasiga sinxronlashtirishga imkon beradi',
  'sync-index-answer-1' => 'Tillarni sinxronlashtirish jarayoni ma\'lumotlar bazasida saqlash uchun barcha fayllarni tillardagi fayllarga o\'tkazadi. Va keyin veb-saytdagi barcha ma\'lumotlar bazasidan yuklanadi. Buning afzalligi shundaki, siz tarjimalaringizni davom ettirishingiz mumkin, hatto kelajakdagi yangiliklarni ham qo\'llaysiz.',
  'sync-index-answer-2' => 'Iltimos, til matnlarini tahrirlash imkoniyatiga ega ekanligingizni unutmang, hatto siz til matnini ma\'lumotlar bazasiga sinxronlashtirmaysiz. Sinxronizatsiya qilinmasdan, siz til fayllarini to\'g\'ridan-to\'g\'ri tahrir qilasiz va agar siz kelajakdagi yangilanishlarni qo\'llasangiz, sizning tahriringiz ustiga yozilishi mumkin.',
  'sync-index-help' => 'Sinxronizatsiya jarayoni 10 daqiqagacha davom etishi mumkin. Iltimos, sizning hosting serveringiz maksimal ijro etish vaqti 10 daqiqaga teng yoki undan ko\'p bo\'lgan vaqtga ruxsat berganligiga ishonch hosil qiling. Aks holda, sinxronlash jarayonida bajarilish xatolariga duch kelishingiz mumkin. Agar xato yuz bersa, til fayllarini tiklash uchun &quot;Qayta tiklash&quot; tugmasidan foydalaning.',
  'sync-index-max-exe-time' => 'serveringizda max_execution_time:',
  'sync-index-questions' => 'Sinxronlashtirishim kerakmi?',
  'sync-index-second' => 'soniya',
  'sync-lang' => 'Tillarni sinxronlashtirish',
  'sync-lang-seo-title' => 'Boshqarish paneli - Tillarni sinxronlashtirish - :site_name',
  'sync-restore' => 'Qayta tiklash',
  'sync-restore-help' => 'Veb-saytingiz to\'g\'ridan-to\'g\'ri fayllardan til matnini ishlatadi.',
  'sync-title' => 'Tillarni ma\'lumotlar bazasiga sinxronlashtirish',
);
