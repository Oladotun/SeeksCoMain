<?php 
return array (
  'upload-photos' => 'Suratlaringizni yuklang',
  'upload-photos-help' => 'Siz 12 tagacha fotosuratlarni yuklashingiz mumkin',
  'choose-photo' => 'Rasmlarni tanlang',
);