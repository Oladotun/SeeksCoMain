<?php 
return array (
  'seo' => 
  array (
    'edit-setting-session' => 'Boshqarish paneli - Sessiyani tahrirlash - :site_name',
  ),
  'alert' => 
  array (
    'session-updated-success' => 'Sessiya sozlamalari muvaffaqiyatli yangilandi.',
  ),
  'edit' => 'Sessiyani sozlash',
  'edit-desc' => 'Ushbu sahifa veb-sayt sessiyasini sozlash imkonini beradi',
  'session-file' => 'Fayl',
  'session-cookie' => 'Cookie',
  'session-database' => 'Ma&#39;lumotlar bazasi',
  'session-driver' => 'Sessiya haydovchisi',
  'session' => 'Sessiya',
  'update-help' => 'Sessiya drayveri yangilanganidan keyin yana tizimga kirishingiz kerak',
  'session-intro-desc' => 'HTTP tomonidan boshqariladigan dasturlar fuqaroligi bo&#39;lmaganligi sababli, sessiyalar foydalanuvchi haqidagi ma&#39;lumotlarni bir nechta so&#39;rovlar bo&#39;yicha saqlash imkoniyatini beradi. Veb-sayt sessiya ma&#39;lumotlarini saqlashning 3 usulini qo&#39;llab-quvvatlaydi: fayl, cookie-fayllar va ma&#39;lumotlar bazasi. Sessiyani qanday saqlash usulidan qat&#39;i nazar, sessiya ma&#39;lumotlari shifrlangan.',
  'session-file-help' => 'Fayl - sessiyalar laravel_project / storage / framework / сессияlarda saqlanadi.',
  'session-cookie-help' => 'Cookie - sessiyalar xavfsiz, shifrlangan cookie-fayllarda saqlanadi.',
  'session-database-help' => 'Ma&#39;lumotlar bazasi - sessiyalar veb-sayt ma&#39;lumotlar bazasining sessiyalar jadvalida saqlanadi.',
);