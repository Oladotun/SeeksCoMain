<?php
return array (
  'seo' =>
  array (
    'edit-setting-cache' => 'Boshqarish paneli - Keshni tahrirlash - :site_name',
  ),
  'alert' =>
  array (
    'updated-success' => 'Veb-sayt keshi muvaffaqiyatli yaratildi.',
    'deleted-success' => 'Veb-sayt keshi tozalandi.',
  ),
  'manage-website-cache' => 'Veb-sayt keshini boshqarish',
  'manage-website-cache-desc' => 'Ushbu sahifa veb-sayt keshini yaratish yoki tozalashga imkon beradi.',
  'what-are-cached' => 'Kesh nima saqlanmoqda?',
  'what-are-cached-help' => 'U veb-sayt keshining 2 turini yaratadi: 1. marshrut keshi, 2. ko\'rish keshi. Kesh - bu veb-sayt ishlashining katta omili, veb-saytingizni keshlash veb-saytni yuklash ishini sezilarli darajada yaxshilaydi. Qo\'shimcha ma\'lumot uchun Laravel doc ga murojaat qiling.',
  'generate-cache' => 'Kesh yaratish',
  'clear-cache' => 'Keshni tozalash',
  'clear-cache-question' => 'Veb-sayt keshini tozalashni xohlaysizmi?',
  'cache' => 'Kesh',
  'not-cached' => 'Veb-sayt keshlanmagan.',
  'last-cached-at' => 'Veb-sayt keshlangan',
);
