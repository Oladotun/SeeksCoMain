<?php
return array (
  'seo' =>
  array (
    'edit-stripe' => 'Boshqarish paneli - Stripe-ni tahrirlash - :site_name',
    'edit-paypal' => 'Boshqarish paneli - PayPal-ni tahrirlash - :site_name',
    'edit-razorpay' => 'Boshqarish paneli - Razorpay-ni tahrirlash - :site_name',
  ),
  'alert' =>
  array (
    'payment-canceled' => 'To‘lov bekor qilindi.',
    'payment-success' => 'Obuna muvaffaqiyatli amalga oshirildi, iltimos, bir oz kutib turing va hisob-fakturangizni yangilash va ushbu sahifani yangilang.',
    'value-required' => 'talab qilinadi',
    'update-stripe-success' => 'Chiziq sozlamalari muvaffaqiyatli yangilandi.',
    'stripe-disable' => 'Stripe to\'lov shlyuzi o\'chirilgan.',
  ),
  'pay-redirect-message' => 'Iltimos, kuting ... Stripe to\'lov sahifasi ochilmoqda.',
  'pay-stripe' => 'Stripe bilan to‘lang',
  'stripe' => 'Ip',
  'edit-stripe-setting' => 'Stripe Payment Gateway-ni tahrirlash',
  'edit-stripe-setting-desc' => 'Ushbu sahifa Stripe to\'lov shlyuzini yoqish yoki o\'chirish va Stripe sozlamalarini tahrirlash imkonini beradi.',
  'enable-stripe' => 'Stripe to\'lov shlyuzini yoqing',
  'stripe-publishable-key' => 'Stripe nashr etiladigan kalit',
  'stripe-secret-key' => 'Stripe maxfiy kaliti',
  'stripe-webhook-signing-secret' => 'Stripe webhook imzolash siri',
  'stripe-currency-help' => 'Valyuta ma\'lumotlarini qo\'llab-quvvatlash uchun Stripe veb-saytini tekshiring.',
  'stripe-enabled' => 'Ip yoqilgan',
  'stripe-disabled' => 'Ip o‘chirilgan',
  'stripe-webhook' => 'Stripe webhook',
  'stripe-webhook-events' => 'Webhook tadbirlari',
  'stripe-webhook-event-code' => 'kassa.sessiya.tamomlangan, schyot-faktura.pullangan, schyot-faktura.to\'lov_ bajarilmadi',
);
