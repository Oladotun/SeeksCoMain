<?php 
return array (
  'sitemap' => 
  array (
    'state' => 'Shtat',
    'city' => 'Shahar',
  ),
  'alert' => 
  array (
    'url-starts-with' => 'URL http: // yoki https: // bilan boshlanishi kerak',
  ),
  'item-feature-image-url-help' => 'Rasm urlini kiritish http: // yoki https: // bilan boshlanadi.',
  'item-gallery-images-url-help' => 'Rasm URL manzillarini kiritish http: // yoki https: // va har bir URL uchun bitta satrdan boshlanadi',
  'column-item-feature-image' => 'ro&#39;yxat xususiyatining rasm URL manzili',
  'column-item-gallery-images' => 'galereya rasmlarining URL manzillarini ro&#39;yxati',
  'csv-file-upload-listing-instruction-columns' => 'Ro&#39;yxat uchun ustunlar: sarlavha, slug (variant), manzil (variant), shahar, shtat, mamlakat, kenglik (variant), uzunlik (variant), pochta indeksi, tavsif, telefon (variant), veb-sayt (variant), facebook (parametr) ), twitter (parametr), LinkedIn (parametr), youtube identifikatori (parametr), taniqli rasm URL manzili (parametr), galereya rasmlarining URL manzillari (parametr).',
  'csv-file-upload-listing-instruction-image-urls' => 'URL-lar ikkala taniqli rasm URL-larida va galereya rasmlari URL-lar ustunlarida http: // yoki https: // bilan boshlanishi kerak.',
  'csv-file-upload-listing-instruction-gallery-images-urls' => 'Galereya rasmlari URL manzilida, iltimos, har bir rasm URL manzilini bo&#39;sh joy bilan ajratib oling.',
);