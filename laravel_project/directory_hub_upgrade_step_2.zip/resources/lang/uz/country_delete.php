<?php
return array (
  'alert' =>
  array (
    'country-delete-error-setting' => 'Ushbu mamlakat veb-sayt uchun sukut bo\'yicha mamlakatdir, iltimos, Admin boshqaruv paneli&gt; Sozlamalar&gt; Umumiy&gt; Ma\'lumotlar yorlig\'iga o\'ting.',
    'at-least-one-country' => 'Veb-sayt kamida bitta mamlakat yozuviga ega bo\'lishi kerak.',
  ),
  'delete-country-warning' => 'Mamlakat yozuvini o\'chirib tashlasangiz, uning barcha ro\'yxatlari, shtatlari va shaharlari haqidagi ma\'lumotlar o\'chib ketadi.',
  'delete-state-warning' => 'Shtat yozuvlarini o&#39;chirib tashlasangiz, uning barcha qo&#39;shilgan ro&#39;yxatlari va shahar ma&#39;lumotlari o&#39;chiriladi.',
  'delete-city-warning' => 'Shtat yozuvlarini o&#39;chirib tashlash, shuningdek, uning ro&#39;yxatidagi barcha ma&#39;lumotlarni o&#39;chirib tashlaydi.',
);
