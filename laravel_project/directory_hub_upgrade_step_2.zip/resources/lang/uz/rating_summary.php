<?php 
return array (
  '1-stars' => '1 Yulduzlar',
  '2-stars' => '2 yulduz',
  '3-stars' => '3 yulduz',
  '4-stars' => '4 yulduz',
  '5-stars' => '5 yulduz',
  'based-on-review' => ' :item_rating_count sharhiga asoslanib',
  'based-on-reviews' => ' :item_rating_count sharhlari asosida',
  'sort-by' => 'Saralash turi',
  'sort-by-newest' => 'Yangisi birinchi',
  'sort-by-oldest' => 'Eng qadimgi birinchi',
  'sort-by-highest' => 'Eng yuqori baholangan',
  'sort-by-lowest' => 'Eng past baholangan',
  'contact' => 'Aloqa',
  'managed-by' => 'Menejer',
);