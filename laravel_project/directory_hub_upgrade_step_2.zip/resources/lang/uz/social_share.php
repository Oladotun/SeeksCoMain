<?php 
return array (
  'blogger' => 'Blogger',
  'buffer' => 'Bufer',
  'evernote' => 'Evernote',
  'facebook' => 'Facebook',
  'line' => 'Chiziq',
  'linkedin' => 'LinkedIn',
  'pinterest' => 'Pinterest',
  'reddit' => 'Reddit',
  'skype' => 'Skype',
  'telegram' => 'Telegram',
  'twitter' => 'Twitter',
  'viber' => 'Viber',
  'wechat' => 'Wechat',
  'weibo' => 'Vaybo',
  'whatsapp' => 'Whatsapp',
  'wordpress' => 'Wordpress',
);