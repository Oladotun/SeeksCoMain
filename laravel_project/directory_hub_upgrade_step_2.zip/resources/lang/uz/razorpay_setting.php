<?php
return array (
  'seo' =>
  array (
    'edit-razorpay' => 'Boshqarish paneli - Razorpay-ni tahrirlash - :site_name',
  ),
  'alert' =>
  array (
    'value-required' => 'talab qilinadi',
    'update-razorpay-success' => 'Razorpay sozlamasi muvaffaqiyatli yangilandi.',
  ),
  'edit-razorpay-setting' => 'Razorpay to\'lov shlyuzini tahrirlash',
  'edit-razorpay-setting-desc' => 'Ushbu sahifa sizga Razorpay to\'lov shlyuzini yoqish yoki o\'chirish va Razorpay sozlamalarini tahrirlash imkonini beradi.',
  'razorpay-enabled' => 'Razorpay yoqilgan',
  'razorpay-disabled' => 'Razorpay nogiron',
  'enable-razorpay' => 'Razorpay to\'lov shlyuzini yoqing',
);
