<?php 
return array (
  'demo-login-credentials' => 'Iltimos, kirish uchun bizning demo hisobimizdan foydalaning',
  'admin-account' => 'Admin',
  'user-account' => 'Foydalanuvchi',
  'copy-to-login' => 'Nusxalash',
);