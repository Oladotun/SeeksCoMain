<?php
return array (
  'get-directions' => 'Yo\'nalishlarni oling',
  'google-map' => 'Google xarita',
  'map' => 'Xarita',
  'google-map-api-key' => 'Google API kaliti',
  'open-street-map' => 'OpenStreetMap',
  'select-map' => 'Xaritani tanlang',
  'select-map-help' => 'Veb-saytda qaysi xaritani ishlatishni tanlang',
  'select-lat-lng-on-map' => 'Lat va Lng ni olish uchun xaritani bosing',
);
