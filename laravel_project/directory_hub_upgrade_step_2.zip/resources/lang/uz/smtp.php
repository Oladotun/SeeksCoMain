<?php 
return array (
  'from-email' => 'Elektron pochtadan',
  'from-name' => 'Ismdan',
  'smtp' => 'SMTP',
  'smtp-enabled' => 'SMTP-ni yoqish',
  'smtp-encryption' => 'SMTP shifrlash',
  'smtp-encryption-null' => 'NULL',
  'smtp-encryption-ssl' => 'SSL',
  'smtp-encryption-tls' => 'TLS',
  'smtp-host' => 'SMTP xosti',
  'smtp-password' => 'SMTP paroli',
  'smtp-port' => 'SMTP port',
  'smtp-username' => 'SMTP foydalanuvchi nomi',
);