<?php 
return array (
  'delete-custom-field-warning' => 'Maxsus maydon o&#39;chirilsa, ushbu maxsus maydon bilan bog&#39;liq bo&#39;lgan ro&#39;yxat xususiyatlari ma&#39;lumotlari ham o&#39;chiriladi.',
);