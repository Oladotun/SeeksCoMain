<?php
return array (
  'oauth-redirect-uri' => 'OAuth qayta yo\'naltirish URI',
);
