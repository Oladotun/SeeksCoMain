<?php 
return array (
  'category-description' => 'Kategoriya tavsifi',
  'records' => 'jami yozuvlar',
);