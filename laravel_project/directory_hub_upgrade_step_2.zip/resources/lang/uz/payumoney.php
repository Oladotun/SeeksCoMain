<?php
return array (
  'seo' =>
  array (
    'edit-payumoney' => 'Boshqarish paneli - Payumoney sozlamalarini tahrirlash - :site_name',
  ),
  'alert' =>
  array (
    'payumoney-disable' => 'Payumoney to\'lov shlyuzi o\'chirilgan.',
    'payment-canceled' => 'Payumoney to\'lovi bekor qilindi',
    'invalid-transaction' => 'Noto\'g\'ri tranzaksiya, qayta urinib ko\'ring.',
    'payment-paid' => 'Payumoney to\'lovi muvaffaqiyatli amalga oshirildi',
    'value-required' => 'Kerakli',
    'updated-success' => 'Payumoney sozlamalari muvaffaqiyatli yangilandi',
  ),
  'pay-redirect-message' => 'Iltimos, kuting .. Payumoney to\'lov sahifasiga yo\'naltirish.',
  'pay-payumoney' => 'Payumoney bilan to\'lash',
  'edit-payumoney-setting' => 'Payumoney to\'lov shlyuzini tahrirlash',
  'edit-payumoney-setting-desc' => 'Ushbu sahifa sizga Payumoney to\'lov shlyuzini yoqish yoki o\'chirish va Payumoney sozlamalarini tahrirlash imkonini beradi.',
  'enable-payumoney' => 'Payumoney to\'lov shlyuzini yoqing',
  'merchant-key' => 'Savdo kaliti',
  'merchant-salt' => 'Savdogar tuzi',
  'mode' => 'Rejim',
  'live' => 'Jonli rejim',
  'test' => 'Sinov rejimi',
  'payumoney-enabled' => 'Payumoney yoqilgan',
  'payumoney-disabled' => 'Payumoney o\'chirilgan',
  'payumoney' => 'Payumoney',
);
