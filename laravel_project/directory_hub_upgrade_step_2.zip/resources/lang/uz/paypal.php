<?php
return array (
  'seo' =>
  array (
    'edit-paypal' => 'Boshqarish paneli - PayPal-ni tahrirlash - :site_name',
  ),
  'alert' =>
  array (
    'value-required' => 'talab qilinadi',
    'update-paypal-success' => 'PayPal sozlamalari muvaffaqiyatli yangilandi.',
  ),
  'edit-paypal-setting' => 'PayPal to\'lov shlyuzini tahrirlash',
  'edit-paypal-setting-desc' => 'Ushbu sahifa sizga PayPal to\'lov shlyuzini yoqish yoki o\'chirish va PayPal sozlamalarini tahrirlash imkonini beradi.',
  'enable-paypal' => 'PayPal to\'lov shlyuzini yoqing',
  'paypal-enabled' => 'PayPal yoqilgan',
  'paypal-disabled' => 'PayPal o\'chirilgan',
  'paypal-sandbox' => 'Sandbox',
  'paypal-live' => 'Jonli',
);
