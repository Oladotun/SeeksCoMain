<?php 
return array (
  'item' => 
  array (
    'alert' => 
    array (
      'user-not-exist' => 'Foydalanuvchi hisobi mavjud emas',
    ),
    'delete-feature-image' => 'Xususiyat rasmini olib tashlash',
    'myself' => 'O&#39;zim',
    'listing-owner' => 'Listing egasi',
    'listing-owner-help' => 'Yaratgandan so&#39;ng ro&#39;yxat egasi o&#39;zgarishi mumkin emas',
  ),
  'user' => 
  array (
    'delete-profile-image' => 'Olib tashlash',
  ),
  'item-leads' => 
  array (
    'seo' => 
    array (
      'index' => 'Boshqarish paneli - ro&#39;yxat ro&#39;yxatlari - :site_name',
      'create' => 'Boshqarish paneli - ro&#39;yxatni yaratish - :site_name',
      'edit' => 'Boshqarish paneli - Ro&#39;yxatning etakchisini tahrirlash - :site_name',
    ),
    'alert' => 
    array (
      'listing-not-exist' => 'Tanlangan ro&#39;yxat mavjud emas',
      'item-lead-created' => 'Muvaffaqiyatli yangi ro&#39;yxat rahbari yaratildi.',
      'item-lead-updated' => 'Ro&#39;yxat etakchisi muvaffaqiyatli yangilandi.',
      'item-lead-deleted' => 'Ro&#39;yxat etakchisi muvaffaqiyatli o&#39;chirildi.',
      'item-lead-deleted-error' => 'Siz boshqa foydalanuvchiga tegishli ro&#39;yxat o&#39;chirilishini o&#39;chira olmaysiz.',
      'contact-form-submitted' => 'Aloqa formasi muvaffaqiyatli yuborildi.',
    ),
    'admin-index' => 'Ro&#39;yxat etakchilarini boshqarish',
    'admin-index-desc' => 'Ushbu sahifa veb-saytlar ro&#39;yxatini boshqarish imkoniyatini beradi.',
    'add-a-lead' => 'Yangi qo&#39;rg&#39;oshin',
    'listing' => 'Listing',
    'listing-default' => 'Korxonalar ro&#39;yxatini tanlang',
    'listing-help' => 'Etakchi ro&#39;yxati qaysi biznes ro&#39;yxatiga tegishli',
    'item-lead-name' => 'Ism',
    'item-lead-email' => 'Elektron pochta',
    'item-lead-phone' => 'Telefon',
    'item-lead-subject' => 'Mavzu',
    'item-lead-message' => 'Xabar',
    'item-lead-received-at' => 'Qabul qildi',
    'item-leads' => 'Ro&#39;yxat etakchilari',
    'admin-create' => 'Ro&#39;yxatning etakchisini yarating',
    'admin-create-desc' => 'Ushbu sahifa sizning ro&#39;yxatingizni qo&#39;lda yaratishga va veb-saytga saqlashga imkon beradi.',
    'admin-edit' => 'Ro&#39;yxat satrini tahrirlash',
    'admin-edit-desc' => 'Ushbu sahifada ro&#39;yxat satrini qo&#39;lda tahrirlash va veb-saytga yangilash mumkin.',
    'email' => 
    array (
      'subject' => 'Biznes ro&#39;yxatining etakchisi qabul qilindi',
      'description-user' => 'Sizning biznesingiz ro&#39;yxati sahifasida yangi aloqa operatori paydo bo&#39;ldi.',
      'description-admin' => 'Sizning kompaniyangiz ro&#39;yxatidagi sahifalardan birida yangi aloqa raqamini oldingiz. Biznes ro&#39;yxatidagi barcha kontaktlarni ko&#39;rish uchun sizning boshqaruv panelingizga kiring.',
      'action-text' => 'Barcha etakchilarni ko&#39;rish',
    ),
  ),
  'setting' => 
  array (
    'item-lead-enable' => 'Ro&#39;yxatning etakchi formasida Google reCaptcha-ni yoqing',
  ),
);