<?php
return array (
  'payment' => 'To\'lov',
  'paypal' => 'PayPal',
  'razorpay' => 'Razorpay',
  'enable-paypal' => 'PayPal-ni yoqing',
  'enable-razorpay' => 'Razoray-ni yoqing',
  'paypal-ipn' => 'PayPal IPN',
  'pay-paypal' => 'PayPal bilan to\'lash',
  'pay-razorpay' => 'Razorpay bilan to\'lang',
  'paypal-disable' => 'PayPal to\'lov shlyuzi o\'chirilgan.',
);
