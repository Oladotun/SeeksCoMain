<?php
return array (
  'filters' => 'Filtrlar',
  'categories' => 'Kategoriyalar',
  'sort-by' => 'Saralash turi',
  'update-result' => 'Yangilash',
  'sort-by-newest' => 'Yangisi birinchi',
  'sort-by-oldest' => 'Eng qadimgi birinchi',
  'sort-by-highest' => 'Eng yuqori baholangan',
  'sort-by-lowest' => 'Eng past baholangan',
  'show-more' => 'Ko\'proq ko\'rsatish',
  'show-less' => 'Kamroq ko\'rsatish',
);
