<?php
return array (
  'purchase-button' => 'Xarid qilish',
  'purchase-desc' => 'Biz ushbu mahsulotni CodeCanyon-dan tashqarida sotmaymiz. Qo\'llab-quvvatlash va umr bo\'yi yangilanish uchun ushbu asl muallifdan sotib oling.',
);
