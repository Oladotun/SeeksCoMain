<?php
return array (
  'view-all-latest' => 'Barcha ro\'yxatlarni ko\'rish',
);
